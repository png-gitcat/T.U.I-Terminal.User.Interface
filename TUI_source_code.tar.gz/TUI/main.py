#######################
# Name: "TUI"
# By: "PNG_GITCAT"
# Version: 1.0
# Remix by: "None" <--- type your name here to give credits of remixing my project
#######################
#import modules (DONT TOUCH UNLESS ADDING MODULES)
import subprocess as sub
from subprocess import run as cmd
import getpass as gp
import threading as trd
import urllib.request
import urllib.error
import json
import os
import platform as _platform
import sys as _sys
import shutil
import site as _site
import configparser as _cp
import time
import distro
import tkinter as tk
import customtkinter as ctk

# ── Base directory ──
if getattr(_sys, 'frozen', False):
    BASE_DIR = os.path.dirname(_sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
import psutil
try:
    from CTkColorPicker import AskColor as _AskColor
except ImportError:
    _AskColor = None


#Classes
class TUI:
    #Configure /home/____/.TUI/conf/core.config
    class addSettings:
        global username
        username = gp.getuser()

        os.makedirs(rf"/home/{username}/.TUI/conf/", exist_ok=True)

        # ── core.config (configparser) ──
        global core_path
        core_path = rf"/home/{username}/.TUI/conf/core.config"
        _core = _cp.ConfigParser()
        if not os.path.isfile(core_path):
            _core["TUI"] = {
                "title":      "T.U.I | Terminal.User.Interface",
                "theme":      "theme_system",
                "width":      "600",
                "height":     "580",
                "acc_dark":   "#3e3c88",
                "acc_light":  "#1d1c44",
                "acc_sys":    "#2a2860",
                "frame_mode": "frame_rebuild"
            }
            with open(core_path, "w") as f:
                _core.write(f)
        global core
        core = _cp.ConfigParser()
        core.read(core_path)

        # ── settings.config (configparser) ──
        global stg_path
        stg_path = rf"/home/{username}/.TUI/conf/settings.config"
        _cfg = _cp.ConfigParser()
        if not os.path.isfile(stg_path):
            _cfg["QuickSettings"] = {
                "theme_mode":      "dark",
                "accent_color":    "#3e3c88",
                "start_directory": rf"/home/{username}"
            }
            _cfg["System"] = {
                "fs_search_mode":  "false",
                "show_cpu_memory": "false",
                "after_driver_fix":"Ask"
            }
            _cfg["ColorsThemes"] = {}
            _cfg["About"] = {}
            with open(stg_path, "w") as f:
                _cfg.write(f)
        global stg
        stg = _cp.ConfigParser()
        stg.read(stg_path)

    class addVariables:
        global title, theme, geometry, acc_dark, acc_light, acc_sys, frame_mode

        def _rgb_to_hex(s, fallback):
            try:
                r, g, b = [int(x.strip()) for x in s.split(",")]
                return f"#{r:02x}{g:02x}{b:02x}"
            except:
                return fallback

        title      = core.get("TUI", "title",      fallback="T.U.I | Terminal.User.Interface")
        theme      = core.get("TUI", "theme",      fallback="theme_system")
        geometry   = [core.get("TUI", "width", fallback="600"), core.get("TUI", "height", fallback="550")]
        acc_dark   = _rgb_to_hex(core.get("TUI", "acc_dark",  fallback="#3e3c88"), "#5691e9")
        acc_light  = _rgb_to_hex(core.get("TUI", "acc_light", fallback="#1d1c44"),  "#173e78")
        acc_sys    = _rgb_to_hex(core.get("TUI", "acc_sys",   fallback="#2a2860"),  "#2c5593")
        frame_mode = core.get("TUI", "frame_mode", fallback="frame_rebuild")

    class Program:
        def app():
            global win, acc_color

            # ── First run check ──
            first_run = stg.getboolean("About", "first_run_done", fallback=False) == False

            if first_run:
                # ── Setup greeting window ──
                setup_win = ctk.CTk()
                setup_win.title("Welcome to T.U.I")
                setup_win.geometry("540x460")
                setup_win.resizable(False, False)
                try:
                    setup_win.iconphoto(True, tk.PhotoImage(file=os.path.join(BASE_DIR, "resources", "icons", "win_icon.png")))
                except: pass
                ctk.set_appearance_mode("dark")

                _acc = "#3e3c88"
                _grn = "#48aa30"
                _grn_h = "#4cdc28"
                _dim = "#5a5a7a"

                ctk.CTkLabel(setup_win, text="> TUI",
                    font=("Share Tech Mono", 36, "bold"), text_color=_grn).pack(pady=(32, 0))
                ctk.CTkLabel(setup_win, text="Terminal · User · Interface",
                    font=("Share Tech Mono", 13), text_color=_dim).pack()
                ctk.CTkLabel(setup_win, text="Welcome! Here's a quick overview before you start.",
                    font=("Share Tech Mono", 12), text_color="white").pack(pady=(16, 8))

                info_frame = ctk.CTkFrame(setup_win, fg_color="#1d1c44", corner_radius=12)
                info_frame.pack(padx=40, pady=(0, 16), fill="x")
                for icon, txt in [
                    ("📦", "Package Manager — APT, Flatpak & AppImage"),
                    ("📁", "FileSystem Manager — Browse & manage files"),
                    ("⚙️",  "System — Drivers, Apps & OS info"),
                    ("📋", "Cheatsheet — Linux commands at a glance"),
                    ("🎨", "Settings — Customize theme & accent color"),
                ]:
                    row = ctk.CTkFrame(info_frame, fg_color="transparent")
                    row.pack(fill="x", padx=16, pady=5)
                    ctk.CTkLabel(row, text=icon, font=("Share Tech Mono", 14), width=30).pack(side="left")
                    ctk.CTkLabel(row, text=txt, font=("Share Tech Mono", 12),
                        text_color="white", anchor="w").pack(side="left", padx=8)

                ctk.CTkLabel(setup_win, text='"Be Free, The Easy Way..."',
                    font=("Share Tech Mono", 11, "italic"), text_color=_dim).pack(pady=(0, 16))

                def start_app():
                    stg.set("About", "first_run_done", "true")
                    with open(stg_path, "w") as f:
                        stg.write(f)
                    setup_win.destroy()

                ctk.CTkButton(setup_win, text="Let's Go! 🚀", width=180, height=44,
                    font=("Share Tech Mono", 14), fg_color=_grn, hover_color=_grn_h,
                    corner_radius=50, command=start_app).pack(pady=(0, 16))

                ctk.CTkLabel(setup_win, text="tui-linux.netlify.app  •  github.com/png-gitcat",
                    font=("Share Tech Mono", 10), text_color=_dim).pack()

                setup_win.mainloop()

            # ── Apply settings.config overrides ──
            stg_theme  = stg.get("QuickSettings", "theme_mode",   fallback=None)
            stg_accent = stg.get("QuickSettings", "accent_color", fallback=None)

            if stg_theme:
                ctk.set_appearance_mode(stg_theme)
                acc_color = stg_accent if stg_accent else acc_dark
            elif theme == "theme_system":
                ctk.set_appearance_mode("system")
                acc_color = acc_sys
            elif theme == "theme_dark":
                ctk.set_appearance_mode("dark")
                acc_color = acc_dark
            elif theme == "theme_light":
                ctk.set_appearance_mode("light")
                acc_color = acc_light
            else:
                ctk.set_appearance_mode("dark")
                acc_color = acc_dark

            if stg_accent:
                acc_color = stg_accent

            # ── RGB Color System ──
            def _hex_to_rgb(h):
                h = h.lstrip("#")
                return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

            def _rgb(r, g, b):
                return f"#{max(0,min(255,r)):02x}{max(0,min(255,g)):02x}{max(0,min(255,b)):02x}"

            def contrast_text(hex_color):
                """Return black or white depending on background luminance."""
                r, g, b = _hex_to_rgb(hex_color)
                luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
                return "#000000" if luminance > 0.55 else "#ffffff"

            global acc_hover, acc_active, acc_border, acc_subtle, acc_muted, clr_green, clr_green_h, clr_red, clr_red_h, clr_grey, clr_grey_h, clr_orange, clr_orange_h, clr_scroll, clr_scroll_h, clr_dim, acc_fg

            _r, _g, _b = _hex_to_rgb(acc_color)
            acc_hover   = _rgb(_r + 45, _g + 45, _b + 45)   # lighter — hover state
            acc_active  = _rgb(_r - 25, _g - 25, _b - 25)   # darker  — active/pressed
            acc_border  = _rgb(_r - 60, _g - 60, _b - 60)   # border
            acc_subtle  = _rgb(_r - 100,_g - 100,_b - 100)  # deep background
            acc_muted   = _rgb(_r - 40, _g - 40, _b - 40)   # inactive tab

            # Fixed semantic colors (non-accent)
            clr_green   = _rgb(72,  170, 48)    # success / create
            clr_green_h = _rgb(76,  220, 40)
            clr_red     = _rgb(192, 0,   0)     # danger / delete
            clr_red_h   = _rgb(255, 0,   0)
            clr_grey    = _rgb(110, 110, 110)   # neutral
            clr_grey_h  = _rgb(175, 175, 175)
            clr_orange  = _rgb(241, 105, 1)     # home button
            clr_orange_h= _rgb(255, 151, 65)
            clr_scroll  = _rgb(133, 142, 221)   # scrollbar
            clr_scroll_h= _rgb(203, 208, 255)
            clr_dim     = _rgb(90,  90,  122)   # subtle text

            # Auto text color for accent backgrounds
            acc_fg = contrast_text(acc_color)

            win = ctk.CTk()
            win.title(title)
            win.geometry(f"{geometry[0]}x{geometry[1]}")
            win.resizable(False, False)
            try:
                win.iconphoto(True, tk.PhotoImage(file=os.path.join(BASE_DIR, "resources", "icons", "win_icon.png")))
            except: pass

            # ── Register custom font ──
            try:
                _font_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    "resources", "fonts", "primary.ttf")
                if os.path.isfile(_font_path):
                    ctk.FontManager.load_font(_font_path)
            except Exception:
                pass

            # ── Global CPU/RAM setup ──
            cpu_mem_enabled = stg.getboolean("System", "show_cpu_memory", fallback=False)
            _make_cpu_label = lambda parent: None  # placeholder

            if cpu_mem_enabled and psutil:
                _cpu_overlay = ctk.CTkLabel(win, text="CPU:—%  RAM:—MB",
                    font=("Share Tech Mono", 9), text_color="white",
                    fg_color=acc_border, corner_radius=6, anchor="e")
                _cpu_overlay.place(relx=1.0, y=4, anchor="ne", x=-4)

                def _update_cpu():
                    if not win.winfo_exists():
                        return
                    cpu = psutil.cpu_percent(interval=None)
                    ram = psutil.virtual_memory()
                    _cpu_overlay.configure(
                        text=f"  CPU:{cpu:.0f}%  RAM:{ram.used//(1024**2)}MB  ")
                    _cpu_overlay.lift()
                    win.after(2000, _update_cpu)

                win.after(500, _update_cpu)

            # ── Home Frame ──
            frame_home    = ctk.CTkFrame(master=win, bg_color="transparent")
            title_home    = ctk.CTkLabel(master=frame_home, text_color=acc_color, text=title, font=("Share Tech Mono", 20, "italic"))
            subtitle_home = ctk.CTkLabel(master=frame_home, text_color=acc_color, text="Be Free, The Easy way...", font=("Share Tech Mono", 15, "italic"))

            # ── Pkg Frame ──
            frame_pkg    = ctk.CTkFrame(master=win, bg_color="transparent")
            title_pkg    = ctk.CTkLabel(frame_pkg, text="Package Manager", font=('Share Tech Mono', 30, "italic"), text_color=acc_color)
            title_pkg.pack(side="top", padx=(0, 350), pady=5)
            subtitle_pkg = ctk.CTkLabel(frame_pkg, text="Control ALL APP'S YOUR WAY", font=("Share Tech Mono", 15, "italic"), text_color=acc_color)
            subtitle_pkg.pack(side="top", padx=(0, 368), pady=5)
            frame_groups_pkg  = ctk.CTkFrame(frame_pkg, width=575, height=210, border_color=acc_color, border_width=2, fg_color="transparent")
            frame_groups_home = ctk.CTkScrollableFrame(master=frame_home, fg_color="transparent", width=540, height=360, scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h, border_width=5, border_color=acc_color)
            frame_groups_home.place(x=30, y=90)
            frame_groups_pkg.place(x=5, y=140)

            # ── Home Cards ──
            button_group_home_pkg = ctk.CTkFrame(master=frame_groups_home, width=450, height=75, fg_color=acc_color)
            button_group_home_pkg.pack(side="top", pady=(0, 20))
            button_group_home_pkg.pack_propagate(False)
            button_group_home_pkg_title = ctk.CTkLabel(master=button_group_home_pkg, text="Package Manager", font=("Share Tech Mono", 20, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_pkg_title.pack(side="top", padx=(0, 220))
            button_group_home_pkg_dis = ctk.CTkLabel(master=button_group_home_pkg, text="Control ALL APP'S YOUR WAY: APT, Flathub, AppImage Converter", font=("Share Tech Mono", 10, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_pkg_dis.pack(side="top", padx=(0, 70))

            button_group_home_fs = ctk.CTkFrame(master=frame_groups_home, width=450, height=75, fg_color=acc_color)
            button_group_home_fs.pack(side="top", pady=(0, 20))
            button_group_home_fs.pack_propagate(False)
            button_group_home_fs_title = ctk.CTkLabel(master=button_group_home_fs, text="FileSystem", font=("Share Tech Mono", 20, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_fs_title.pack(side="top", padx=(0, 290))
            button_group_home_fs_dis = ctk.CTkLabel(master=button_group_home_fs, text="Control the WHOLE FILESYSTEM With ADMIN Access: add, remove, info, search, change", font=("Share Tech Mono", 8, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_fs_dis.pack(side="top", padx=(0, 60))

            button_group_home_df = ctk.CTkFrame(master=frame_groups_home, width=450, height=75, fg_color=acc_color)
            button_group_home_df.pack(side="top", pady=(0, 20))
            button_group_home_df.pack_propagate(False)
            button_group_home_df_title = ctk.CTkLabel(master=button_group_home_df, text="System", font=("Share Tech Mono", 20, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_df_title.pack(side="top", padx=(0, 295))
            button_group_home_df_dis = ctk.CTkLabel(master=button_group_home_df, text="System Tools: Driver Fixer & More", font=("Share Tech Mono", 10, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_df_dis.pack(side="top", padx=(0, 2))

            button_group_home_gb = ctk.CTkFrame(master=frame_groups_home, width=450, height=75, fg_color=acc_color)
            button_group_home_gb.pack(side="top", pady=(0, 20))
            button_group_home_gb.pack_propagate(False)
            button_group_home_gb_title = ctk.CTkLabel(master=button_group_home_gb, text="GNU/GRUB", font=("Share Tech Mono", 20, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_gb_title.pack(side="top", padx=(0, 295))
            button_group_home_gb_dis = ctk.CTkLabel(master=button_group_home_gb, text="!!SAFELY!! Modify your Bootloader: #GRUB FIXER(Version:2)#, Plymoths .etc", font=("Share Tech Mono", 8, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_gb_dis.pack(side="top", padx=(0, 2))

            button_group_home_cs = ctk.CTkFrame(master=frame_groups_home, width=450, height=75, fg_color=acc_color)
            button_group_home_cs.pack(side="top", pady=(0, 20))
            button_group_home_cs.pack_propagate(False)
            button_group_home_cs_title = ctk.CTkLabel(master=button_group_home_cs, text="Cheatsheet", font=("Share Tech Mono", 20, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_cs_title.pack(side="top", padx=(0, 235))
            button_group_home_cs_dis = ctk.CTkLabel(master=button_group_home_cs, text="Linux Terminal Commands: Simple & Advanced", font=("Share Tech Mono", 10, "bold"), text_color=acc_fg, bg_color="transparent")
            button_group_home_cs_dis.pack(side="top", padx=(0, 2))

            # ── Pkg Buttons ──
            button_pkg_apt     = ctk.CTkButton(frame_groups_pkg, width=560, height=40, text="APT",              text_color=acc_fg, fg_color=acc_color, hover_color=acc_hover, command=lambda: toAPT())
            button_pkg_flathub = ctk.CTkButton(frame_groups_pkg, width=560, height=40, text="Flathub",          text_color=acc_fg, fg_color=acc_color, hover_color=acc_hover, command=lambda: toFlathub())
            button_pkg_amta    = ctk.CTkButton(frame_groups_pkg, width=560, height=40, text="AppImage >>> APP", text_color=acc_fg, fg_color=acc_color, hover_color=acc_hover, command= lambda: toAmta())

            # ── Bottom Tab Home ──
            bottom_tab_home       = ctk.CTkFrame(master=frame_home, corner_radius=10, width=600, height=80, fg_color=acc_color)
            bottom_tab_exit_b     = ctk.CTkButton(bottom_tab_home, text="EXIT",     width=10, height=40, corner_radius=50, fg_color=clr_red, hover_color=clr_red_h, border_width=3, border_color=acc_border, command=lambda: Exit())
            bottom_tab_help_b     = ctk.CTkButton(bottom_tab_home, text="Help",     width=10, height=40, corner_radius=50, fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border, command=lambda: show_help(win, "home"))
            bottom_tab_github_b   = ctk.CTkButton(bottom_tab_home, text="GitHub",   width=10, height=40, corner_radius=50, fg_color="#000000", hover_color="#2c2c2c", border_width=3, border_color=acc_border, command=lambda: __import__('webbrowser').open("https://github.com/png-gitcat"))
            bottom_tab_settings_b = ctk.CTkButton(bottom_tab_home, text="Settings", width=10, height=40, corner_radius=50, fg_color=clr_grey, hover_color=clr_grey_h, border_width=3, border_color=acc_border, command=lambda: toSettings())

            # ── Bottom Tab Pkg ──
            bottom_tab_pkg        = ctk.CTkFrame(master=frame_pkg, corner_radius=10, width=600, height=80, fg_color=acc_color)
            bottom_tab_back_pkg_b = ctk.CTkButton(bottom_tab_pkg, text="Back", width=10, height=40, corner_radius=50, fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border, command=lambda: pkgToHome())
            bottom_tab_home_pkg_b = ctk.CTkButton(bottom_tab_pkg, text="Home", width=10, height=40, corner_radius=50, fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border, command=lambda: pkgToHome())
            bottom_tab_help_pkg_b = ctk.CTkButton(bottom_tab_pkg, text="Help",  width=10, height=40, corner_radius=50, fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border, command=lambda: show_help(win, "pkg"))

            # ── Pack Home ──
            frame_home.pack(expand=True, fill="both")
            title_home.pack(pady=0, padx=(0, 230))
            subtitle_home.pack(padx=(0, 370))
            bottom_tab_home.pack(side="bottom", fill="x")
            bottom_tab_home.pack_propagate(False)
            bottom_tab_exit_b.pack(side="left", fill="none", padx=(65, 0))
            bottom_tab_help_b.pack(side="left", fill="none", padx=(65, 0))
            bottom_tab_github_b.pack(side="left", fill="none", padx=(65, 0))
            bottom_tab_settings_b.pack(side="left", fill="none", anchor="center", padx=(65, 0))


            # ── Card hover effects ──
            for card, children in [
                (button_group_home_pkg, [button_group_home_pkg_title, button_group_home_pkg_dis]),
                (button_group_home_fs,  [button_group_home_fs_title,  button_group_home_fs_dis]),
                (button_group_home_df,  [button_group_home_df_title,  button_group_home_df_dis]),
                (button_group_home_gb,  [button_group_home_gb_title,  button_group_home_gb_dis]),
                (button_group_home_cs,  [button_group_home_cs_title,  button_group_home_cs_dis]),
            ]:
                def _on_enter(e, c=card): c.configure(fg_color=acc_hover)
                def _on_leave(e, c=card): c.configure(fg_color=acc_color)
                card.bind("<Enter>", _on_enter)
                card.bind("<Leave>", _on_leave)
                for child in children:
                    child.bind("<Enter>", _on_enter)
                    child.bind("<Leave>", _on_leave)

            # ── Bindings ──
            button_group_home_pkg.bind("<Button-1>", lambda e: toPKG())
            button_group_home_pkg_title.bind("<Button-1>", lambda e: toPKG())
            button_group_home_pkg_dis.bind("<Button-1>", lambda e: toPKG())
            button_group_home_fs.bind("<Button-1>", lambda e: toFS())
            button_group_home_fs_title.bind("<Button-1>", lambda e: toFS())
            button_group_home_fs_dis.bind("<Button-1>", lambda e: toFS())
            button_group_home_df.bind("<Button-1>", lambda e: toSystem())
            button_group_home_df_title.bind("<Button-1>", lambda e: toSystem())
            button_group_home_df_dis.bind("<Button-1>", lambda e: toSystem())
            button_group_home_gb.bind("<Button-1>", lambda e: toGNUGRUB())
            button_group_home_gb_title.bind("<Button-1>", lambda e: toGNUGRUB())
            button_group_home_gb_dis.bind("<Button-1>", lambda e: toGNUGRUB())
            button_group_home_cs.bind("<Button-1>", lambda e: toCheatsheet())
            button_group_home_cs_title.bind("<Button-1>", lambda e: toCheatsheet())
            button_group_home_cs_dis.bind("<Button-1>", lambda e: toCheatsheet())

            # ── Functions ──
            def Exit():
                confirm = ctk.CTkToplevel(win)
                confirm.title("Exit")
                confirm.geometry("300x140")
                confirm.resizable(False, False)
                confirm.after(100, confirm.grab_set)
                ctk.CTkLabel(confirm, text="Exit T.U.I?", font=("Share Tech Mono", 16, "bold"),
                    text_color=acc_color).pack(pady=(20,8))
                ctk.CTkLabel(confirm, text="Are you sure you want to quit?",
                    font=("Share Tech Mono", 11), text_color="white").pack()
                row = ctk.CTkFrame(confirm, fg_color="transparent")
                row.pack(pady=12)
                ctk.CTkButton(row, text="Yes, Exit", width=100, height=32,
                    fg_color=clr_red, hover_color=clr_red_h,
                    command=lambda: exit()).pack(side="left", padx=(0,10))
                ctk.CTkButton(row, text="Cancel", width=90, height=32,
                    fg_color=clr_grey, hover_color=clr_grey_h,
                    command=confirm.destroy).pack(side="left")

            def toPKG():
                frame_home.pack_forget()
                frame_pkg.pack(fill="both", expand=True)
                bottom_tab_pkg.pack(side="bottom", fill="x")
                bottom_tab_pkg.pack_propagate(False)
                bottom_tab_back_pkg_b.pack(side="left", fill="none", padx=(100, 0))
                bottom_tab_home_pkg_b.pack(side="left", fill="none", padx=(100, 0))
                bottom_tab_help_pkg_b.pack(side="left", fill="none", padx=(100, 0))
                frame_groups_pkg.pack_propagate(False)
                button_pkg_apt.pack(side="top", anchor="center", padx=(2, 0), pady=5)
                button_pkg_flathub.pack(side="top", anchor="center", padx=(2, 0), pady=20)
                button_pkg_amta.pack(side="top", anchor="center", padx=(2, 0), pady=20)
                frame_groups_pkg.place(x=5, y=140)

            def pkgToHome():
                frame_pkg.pack_forget()
                bottom_tab_pkg.pack_forget()
                frame_home.pack(expand=True, fill="both")

            # ── APT Window ──
            def toAPT():
                win_apt = ctk.CTkToplevel(win)
                win_apt.title("APT")
                win_apt.geometry(f"{geometry[0]}x{geometry[1]}")
                win_apt.resizable(False, False)

                frame_apt = ctk.CTkFrame(win_apt)
                frame_apt.pack(fill="both", expand=True)

                ctk.CTkLabel(frame_apt, text="APT", text_color=acc_color, font=("Share Tech Mono", 45, "bold")).pack(pady=10)

                entry_name_apt = ctk.CTkEntry(frame_apt, placeholder_text="Name of Package: Example('vlc' or 'gimp' or 'vim' .etc)", width=480)
                entry_name_apt.pack(pady=10)

                operation_apt = ctk.CTkComboBox(frame_apt, border_color=acc_border, fg_color=acc_subtle, border_width=2, width=100, values=["Install", "Remove", "Version"])
                operation_apt.pack(pady=5)

                output_apt = ctk.CTkTextbox(frame_apt, width=500, height=200, font=("Share Tech Mono", 15, "italic"))
                output_apt.pack(pady=10)

                ctk.CTkButton(frame_apt, fg_color=clr_green, hover_color=clr_green_h, text="Start", command=lambda: run_apt()).pack(pady=5, fill="x")

                bottom_tab_apt = ctk.CTkFrame(frame_apt, corner_radius=10, height=80, fg_color=acc_color)
                bottom_tab_apt.pack(side="bottom", fill="x")
                bottom_tab_apt.pack_propagate(False)
                ctk.CTkButton(bottom_tab_apt, text="Back", width=10, height=40, corner_radius=50, fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border, command=lambda: win_apt.destroy()).pack(side="left", padx=(100, 0))
                ctk.CTkButton(bottom_tab_apt, text="Home", width=10, height=40, corner_radius=50, fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border, command=lambda: win_apt.destroy()).pack(side="left", padx=(100, 0))
                ctk.CTkButton(bottom_tab_apt, text="Help",  width=10, height=40, corner_radius=50, fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border, command=lambda: show_help(win, "apt")).pack(side="left", padx=(100, 0))

                def run_apt():
                    pkg    = entry_name_apt.get().strip()
                    action = operation_apt.get()

                    # ── Validation ──
                    if not pkg:
                        output_apt.delete("1.0", "end")
                        output_apt.insert("end", "⚠ Please enter a package name first.\n")
                        return

                    # ── Clear output before each run ──
                    output_apt.delete("1.0", "end")

                    if action == "Install":
                        def run_apt_install():
                            try:
                                win.after(0, lambda: output_apt.insert("end", f"Installing {pkg}...\n"))
                                cmd(["pkexec", "apt", "install", "-y", pkg], text=True, check=True, capture_output=True)
                                win.after(0, lambda: output_apt.insert("end", f"{pkg} is Installed & Ready to Use!\n"))
                            except sub.CalledProcessError as e:
                                if "Unable to locate package" in e.stderr:
                                    win.after(0, lambda: output_apt.insert("end", f"Couldn't find '{pkg}' — check the name!\n"))
                                elif "network" in e.stderr.lower() or "unreachable" in e.stderr.lower() or "connect" in e.stderr.lower():
                                    win.after(0, lambda: output_apt.insert("end", "ERROR: NO INTERNET CONNECTED\n"))
                                else:
                                    win.after(0, lambda: output_apt.insert("end", f"Error:\n{e.stderr}\n"))
                        trd.Thread(target=run_apt_install, daemon=True).start()

                    elif action == "Remove":
                        def run_apt_remove():
                            try:
                                win.after(0, lambda: output_apt.insert("end", f"Removing {pkg}...\n"))
                                cmd(["pkexec", "apt", "remove", "-y", pkg], text=True, check=True, capture_output=True)
                                win.after(0, lambda: output_apt.insert("end", f"{pkg} has been Removed from your System!\n"))
                            except sub.CalledProcessError as e:
                                if "network" in e.stderr.lower() or "unreachable" in e.stderr.lower():
                                    win.after(0, lambda: output_apt.insert("end", "ERROR: NO INTERNET CONNECTED\n"))
                                else:
                                    win.after(0, lambda: output_apt.insert("end", f"Error:\n{e.stderr}\n"))
                        trd.Thread(target=run_apt_remove, daemon=True).start()

                    elif action == "Version":
                        def run_apt_version():
                            try:
                                results = cmd(["apt", "show", pkg], text=True, check=True, capture_output=True)
                                info = {}
                                for line in results.stdout.splitlines():
                                    if line.startswith("Package:"):
                                        info["Name"] = line.split(":", 1)[1].strip()
                                    elif line.startswith("Version:"):
                                        info["Version"] = line.split(":", 1)[1].strip()
                                    elif line.startswith("Installed-Size:"):
                                        info["Size"] = line.split(":", 1)[1].strip()
                                    elif line.startswith("Description:"):
                                        info["Description"] = line.split(":", 1)[1].strip()
                                win.after(0, lambda: output_apt.insert("end",
                                    f"pkg info:\n"
                                    f"Name:        {info.get('Name', 'N/A')}\n"
                                    f"Version:     {info.get('Version', 'N/A')}\n"
                                    f"Size:        {info.get('Size', 'N/A')}\n"
                                    f"Description: {info.get('Description', 'N/A')}\n"
                                ))
                            except sub.CalledProcessError as e:
                                win.after(0, lambda: output_apt.insert("end", f"Couldn't find '{pkg}' — check the name!\n"))
                        trd.Thread(target=run_apt_version, daemon=True).start()

            # ── Flathub Window ──
            def toFlathub():
                win_fh = ctk.CTkToplevel(win)
                win_fh.title("Flathub")
                win_fh.geometry(f"{geometry[0]}x{geometry[1]}")
                win_fh.resizable(False, False)

                frame_fh = ctk.CTkFrame(win_fh)
                frame_fh.pack(fill="both", expand=True)

                ctk.CTkLabel(frame_fh, text="Flathub", text_color=acc_color, font=("Share Tech Mono", 45, "bold")).pack(pady=5)

                # ── Tab buttons ──
                tab_bar = ctk.CTkFrame(frame_fh, fg_color="transparent")
                tab_bar.pack(pady=5)

                # ── Tab frames ──
                tab_search  = ctk.CTkFrame(frame_fh, fg_color="transparent")
                tab_flatpak = ctk.CTkFrame(frame_fh, fg_color="transparent")

                def show_search():
                    tab_flatpak.pack_forget()
                    tab_search.pack(fill="both", expand=True, padx=10)
                    btn_search_tab.configure(fg_color=acc_color)
                    btn_flatpak_tab.configure(fg_color=acc_muted)

                def show_flatpak():
                    tab_search.pack_forget()
                    tab_flatpak.pack(fill="both", expand=True, padx=10)
                    btn_flatpak_tab.configure(fg_color=acc_color)
                    btn_search_tab.configure(fg_color=acc_muted)

                btn_search_tab  = ctk.CTkButton(tab_bar, text="Search",  width=140, height=35, fg_color=acc_color,  command=show_search)
                btn_flatpak_tab = ctk.CTkButton(tab_bar, text="Flatpak", width=140, height=35, fg_color=acc_muted, command=show_flatpak)
                btn_search_tab.pack(side="left", padx=5)
                btn_flatpak_tab.pack(side="left", padx=5)

                # ────────────────────────────
                # SEARCH TAB
                # ────────────────────────────
                search_results = []

                search_row = ctk.CTkFrame(tab_search, fg_color="transparent")
                search_row.pack(pady=10)
                search_input = ctk.CTkEntry(search_row, placeholder_text="Search app name e.g. 'Spotify'", width=370)
                search_input.pack(side="left", padx=(0, 10))
                ctk.CTkButton(search_row, text="Search", width=90, fg_color=acc_color, command=lambda: do_search()).pack(side="left")

                results_box = ctk.CTkTextbox(tab_search, width=480, height=200, font=("Share Tech Mono", 11))
                results_box.pack(pady=5)
                results_box.configure(state="disabled")

                ctk.CTkLabel(tab_search, text="Click a result number then paste the App ID in the Flatpak tab", font=("Share Tech Mono", 10), text_color=clr_scroll).pack()

                def do_search():
                    query = search_input.get().strip()
                    if not query:
                        return
                    def _search():
                        try:
                            url  = "https://flathub.org/api/v2/search"
                            data = json.dumps({"query": query, "filters": []}).encode()
                            req  = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
                            with urllib.request.urlopen(req, timeout=5) as r:
                                result = json.loads(r.read())
                            search_results.clear()
                            for hit in result.get("hits", []):
                                name   = hit.get("name", "N/A")
                                app_id = hit.get("app_id", "N/A")
                                search_results.append((name, app_id))
                            win.after(0, lambda: results_box.configure(state="normal"))
                            win.after(0, lambda: results_box.delete("1.0", "end"))
                            if not search_results:
                                win.after(0, lambda: results_box.insert("end", "No results found.\n"))
                            for i, (name, app_id) in enumerate(search_results):
                                win.after(0, lambda n=name, a=app_id, idx=i: results_box.insert("end", f"{idx+1}. {n}\n   ID: {a}\n\n"))
                            win.after(0, lambda: results_box.configure(state="disabled"))
                        except urllib.error.URLError:
                            win.after(0, lambda: results_box.configure(state="normal"))
                            win.after(0, lambda: results_box.delete("1.0", "end"))
                            win.after(0, lambda: results_box.insert("end", "ERROR: NO INTERNET CONNECTED\n"))
                            win.after(0, lambda: results_box.configure(state="disabled"))
                        except Exception as e:
                            win.after(0, lambda: results_box.configure(state="normal"))
                            win.after(0, lambda: results_box.insert("end", f"Error: {e}\n"))
                            win.after(0, lambda: results_box.configure(state="disabled"))
                    trd.Thread(target=_search, daemon=True).start()

                # ────────────────────────────
                # FLATPAK TAB
                # ────────────────────────────
                ctk.CTkLabel(tab_flatpak, text="Paste App ID from Search tab", font=("Share Tech Mono", 10), text_color=clr_scroll).pack(pady=(10, 2))

                entry_name_fh = ctk.CTkEntry(tab_flatpak, placeholder_text="e.g. 'com.spotify.Client' or 'org.gimp.GIMP'", width=480)
                entry_name_fh.pack(pady=5)

                operation_fh = ctk.CTkComboBox(tab_flatpak, border_color=acc_border, fg_color=acc_subtle, border_width=2, width=100, values=["Install", "Remove", "Version"])
                operation_fh.pack(pady=5)

                output_fh = ctk.CTkTextbox(tab_flatpak, width=480, height=160, font=("Share Tech Mono", 13, "italic"))
                output_fh.pack(pady=5)

                ctk.CTkButton(tab_flatpak, fg_color=clr_green, hover_color=clr_green_h, text="Start", command=lambda: run_fh()).pack(pady=5, fill="x")

                # ── Bottom bar ──
                bottom_tab_fh = ctk.CTkFrame(frame_fh, corner_radius=10, height=80, fg_color=acc_color)
                bottom_tab_fh.pack(side="bottom", fill="x")
                bottom_tab_fh.pack_propagate(False)
                ctk.CTkButton(bottom_tab_fh, text="Back", width=10, height=40, corner_radius=50, fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border, command=lambda: win_fh.destroy()).pack(side="left", padx=(100, 0))
                ctk.CTkButton(bottom_tab_fh, text="Home", width=10, height=40, corner_radius=50, fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border, command=lambda: win_fh.destroy()).pack(side="left", padx=(100, 0))
                ctk.CTkButton(bottom_tab_fh, text="Help",  width=10, height=40, corner_radius=50, fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border, command=lambda: show_help(win, "flathub")).pack(side="left", padx=(100, 0))

                def run_fh():
                    pkg    = entry_name_fh.get().strip()
                    action = operation_fh.get()

                    if not pkg:
                        output_fh.delete("1.0", "end")
                        output_fh.insert("end", "⚠ Please enter an App ID first.\n")
                        return

                    output_fh.delete("1.0", "end")

                    if action == "Install":
                        def run_fh_install():
                            try:
                                win.after(0, lambda: output_fh.insert("end", f"Installing {pkg}...\n"))
                                cmd(["pkexec", "flatpak", "install", "flathub", "-y", pkg], text=True, check=True, capture_output=True)
                                win.after(0, lambda: output_fh.insert("end", f"{pkg} is Installed & Ready to Use!\n"))
                            except sub.CalledProcessError as e:
                                if "not found" in e.stderr.lower():
                                    win.after(0, lambda: output_fh.insert("end", f"Couldn't find '{pkg}' — check the App ID!\n"))
                                elif "network" in e.stderr.lower() or "unreachable" in e.stderr.lower() or "error" in e.stderr.lower():
                                    win.after(0, lambda: output_fh.insert("end", "ERROR: NO INTERNET CONNECTED\n"))
                                else:
                                    win.after(0, lambda: output_fh.insert("end", f"Error:\n{e.stderr}\n"))
                        trd.Thread(target=run_fh_install, daemon=True).start()

                    elif action == "Remove":
                        def run_fh_remove():
                            try:
                                win.after(0, lambda: output_fh.insert("end", f"Removing {pkg}...\n"))
                                cmd(["pkexec", "flatpak", "uninstall", "-y", pkg], text=True, check=True, capture_output=True)
                                win.after(0, lambda: output_fh.insert("end", f"{pkg} has been Removed from your System!\n"))
                            except sub.CalledProcessError as e:
                                if "network" in e.stderr.lower() or "unreachable" in e.stderr.lower():
                                    win.after(0, lambda: output_fh.insert("end", "ERROR: NO INTERNET CONNECTED\n"))
                                else:
                                    win.after(0, lambda: output_fh.insert("end", f"Error:\n{e.stderr}\n"))
                        trd.Thread(target=run_fh_remove, daemon=True).start()

                    elif action == "Version":
                        def run_fh_version():
                            try:
                                results = cmd(["flatpak", "info", pkg], text=True, check=True, capture_output=True)
                                info = {}
                                lines = results.stdout.splitlines()
                                if lines:
                                    info["Name"] = lines[0].strip()
                                for line in lines:
                                    stripped = line.strip()
                                    if stripped.startswith("Version:"):
                                        info["Version"] = stripped.split(":", 1)[1].strip()
                                    elif stripped.startswith("Installed:"):
                                        info["Size"] = stripped.split(":", 1)[1].strip()
                                    elif stripped.startswith("Arch:"):
                                        info["Architecture"] = stripped.split(":", 1)[1].strip()
                                win.after(0, lambda: output_fh.insert("end",
                                    f"pkg info:\n"
                                    f"Name:         {info.get('Name', 'N/A')}\n"
                                    f"Version:      {info.get('Version', 'N/A')}\n"
                                    f"Size:         {info.get('Size', 'N/A')}\n"
                                    f"Architecture: {info.get('Architecture', 'N/A')}\n\n"
                                ))
                            except sub.CalledProcessError as e:
                                win.after(0, lambda: output_fh.insert("end", f"Couldn't find '{pkg}' — check the App ID!\n"))
                        trd.Thread(target=run_fh_version, daemon=True).start()

                # show search tab by default
                show_flatpak()

            #AppImage to APP
            def file_selector(parent, title="Select File", filetypes=None, start_dir=None):
                """
                Custom CTk file selector. Returns the selected path string or None.
                filetypes: list of extensions to filter e.g. ['.AppImage', '.appimage']
                           Pass None to show all files.
                """
                import threading
                result = [None]
                done   = threading.Event()

                sel_win = ctk.CTkToplevel(parent)
                sel_win.title(title)
                sel_win.geometry("620x440")
                sel_win.resizable(False, False)
                sel_win.after(100, sel_win.grab_set)

                current = [os.path.expanduser(start_dir) if start_dir else os.path.expanduser("~")]

                # ── Title bar ──
                top = ctk.CTkFrame(sel_win, fg_color="transparent")
                top.pack(fill="x", padx=14, pady=(12, 4))
                ctk.CTkLabel(top, text=title, font=("Share Tech Mono", 12, "bold"), width=geometry[1], text_color=acc_color).pack(side="top")

                # ── Path bar ──
                path_row = ctk.CTkFrame(sel_win, fg_color="transparent")
                path_row.pack(fill="x", padx=14, pady=(0, 6))
                path_entry = ctk.CTkEntry(path_row, font=("Share Tech Mono", 11))
                path_entry.insert(0, current[0])
                path_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
                ctk.CTkButton(path_row, text="Go", width=44, fg_color=acc_color,
                    command=lambda: navigate(path_entry.get().strip())).pack(side="left", padx=(0, 4))
                ctk.CTkButton(path_row, text="↑ Up", width=54, fg_color=acc_active, hover_color=acc_hover,
                    command=lambda: navigate(str(os.path.dirname(current[0])))).pack(side="left")

                # ── File list ──
                list_frame = ctk.CTkScrollableFrame(sel_win, fg_color="transparent", height=260,
                    scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h,
                    border_width=2, border_color=acc_color)
                list_frame.pack(fill="x", padx=14, pady=(0, 6))

                # ── Selected path display ──
                sel_row = ctk.CTkFrame(sel_win, fg_color="transparent")
                sel_row.pack(fill="x", padx=14, pady=(0, 8))
                ctk.CTkLabel(sel_row, text="Selected:", font=("Share Tech Mono", 11), text_color=clr_dim).pack(side="left", padx=(0, 6))
                sel_entry = ctk.CTkEntry(sel_row, font=("Share Tech Mono", 11))
                sel_entry.pack(side="left", fill="x", expand=True)

                # ── Buttons ──
                btn_row = ctk.CTkFrame(sel_win, fg_color="transparent")
                btn_row.pack(fill="x", padx=14, pady=(0, 12))
                def confirm():
                    result[0] = sel_entry.get().strip() or None
                    done.set()
                    sel_win.destroy()
                def cancel():
                    done.set()
                    sel_win.destroy()
                ctk.CTkButton(btn_row, text="Select", width=100, height=36, fg_color=clr_green, hover_color=clr_green_h,
                    corner_radius=50, command=confirm).pack(side="left", padx=(0, 10))
                ctk.CTkButton(btn_row, text="Cancel", width=100, height=36, fg_color=clr_red, hover_color=clr_red_h,
                    corner_radius=50, command=cancel).pack(side="left")

                def populate(path):
                    for w in list_frame.winfo_children():
                        w.destroy()
                    try:
                        entries = sorted(os.listdir(path), key=lambda x: (not os.path.isdir(os.path.join(path, x)), x.lower()))
                    except PermissionError:
                        ctk.CTkLabel(list_frame, text="Permission denied.", text_color="#c00000",
                            font=("Share Tech Mono", 11, "italic")).pack(anchor="w")
                        return
                    for name in entries:
                        full  = os.path.join(path, name)
                        is_dir = os.path.isdir(full)
                        ext   = os.path.splitext(name)[1].lower()
                        # filter files by extension (dirs always shown)
                        if not is_dir and filetypes and ext not in [f.lower() for f in filetypes]:
                            continue
                        icon  = "📁 " if is_dir else "📄 "
                        row   = ctk.CTkFrame(list_frame, fg_color="transparent")
                        row.pack(fill="x", pady=1)
                        lbl = ctk.CTkLabel(row, text=icon + name,
                            font=("Share Tech Mono", 12, "bold" if is_dir else "normal"),
                            text_color=acc_color if is_dir else "white", anchor="w")
                        lbl.pack(side="left", fill="x", expand=True)
                        def on_click(f=full, d=is_dir):
                            if d:
                                navigate(f)
                            else:
                                sel_entry.delete(0, "end")
                                sel_entry.insert(0, f)
                        lbl.bind("<Button-1>", lambda e, fn=on_click: fn())
                        row.bind("<Button-1>", lambda e, fn=on_click: fn())

                def navigate(path):
                    path = os.path.expanduser(path)
                    if os.path.isdir(path):
                        current[0] = path
                        path_entry.delete(0, "end")
                        path_entry.insert(0, path)
                        populate(path)

                populate(current[0])
                sel_win.wait_window()
                return result[0]

            def toAmta():
                amta_win = ctk.CTkToplevel(win)
                amta_win.title("AppImage >>> APP")
                amta_win.geometry(f"{geometry[0]}x{geometry[1]}")
                amta_win.resizable(False, False)

                # ── Scrollable main frame ──
                amta_frame = ctk.CTkScrollableFrame(amta_win, fg_color="transparent", scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h)
                amta_frame.pack(expand=True, fill="both", padx=20, pady=(20, 0))

                # ── Title ──
                ctk.CTkLabel(amta_frame, text="AppImage to App Converter", text_color=acc_color, font=("Share Tech Mono", 24, "bold", "italic")).pack(anchor="w", pady=(0, 12))

                # ── AppImage Path ──
                ctk.CTkLabel(amta_frame, text="AppImage Path", text_color=clr_dim, font=("Share Tech Mono", 12)).pack(anchor="w")
                row_file = ctk.CTkFrame(amta_frame, fg_color="transparent")
                row_file.pack(fill="x", pady=(2, 8))
                amta_fill_amta_file = ctk.CTkEntry(row_file, placeholder_text=f"/home/{username}/Downloads/MyApp.AppImage", font=("Share Tech Mono", 12))
                amta_fill_amta_file.pack(side="left", expand=True, fill="x", padx=(0, 8))
                ctk.CTkButton(row_file, text="Browse", fg_color=acc_color, width=80,
                    command=lambda: (
                        amta_fill_amta_file.delete(0, "end") or
                        amta_fill_amta_file.insert(0, file_selector(
                            amta_win, title="Select AppImage",
                            filetypes=[".AppImage", ".appimage"],
                            start_dir=f"/home/{username}/Downloads"
                        ) or amta_fill_amta_file.get())
                    )).pack(side="left")

                # ── Icon Path ──
                ctk.CTkLabel(amta_frame, text="Icon Path", text_color=clr_dim, font=("Share Tech Mono", 12)).pack(anchor="w")
                row_img = ctk.CTkFrame(amta_frame, fg_color="transparent")
                row_img.pack(fill="x", pady=(2, 10))
                amta_fill_amta_img = ctk.CTkEntry(row_img, placeholder_text=f"/home/{username}/icons/myapp.png", font=("Share Tech Mono", 12))
                amta_fill_amta_img.pack(side="left", expand=True, fill="x", padx=(0, 8))
                ctk.CTkButton(row_img, text="Browse", fg_color=acc_color, width=80,
                    command=lambda: (
                        amta_fill_amta_img.delete(0, "end") or
                        amta_fill_amta_img.insert(0, file_selector(
                            amta_win, title="Select Icon",
                            filetypes=[".png", ".svg", ".jpg", ".ico"],
                            start_dir=f"/home/{username}"
                        ) or amta_fill_amta_img.get())
                    )).pack(side="left")

                # ── .Desktop fields (2-column grid) ──
                grid = ctk.CTkFrame(amta_frame, fg_color="transparent")
                grid.pack(fill="x", pady=(0, 8))
                grid.columnconfigure(0, weight=1)
                grid.columnconfigure(1, weight=1)

                def labeled_entry(parent, row, col, label, placeholder):
                    ctk.CTkLabel(parent, text=label, text_color=clr_dim, font=("Share Tech Mono", 12)).grid(row=row*2, column=col, sticky="w", padx=(0 if col==0 else 8, 0), pady=(4, 0))
                    e = ctk.CTkEntry(parent, placeholder_text=placeholder, font=("Share Tech Mono", 12))
                    e.grid(row=row*2+1, column=col, sticky="ew", padx=(0 if col==0 else 8, 0), pady=(2, 4))
                    return e

                amta_fill_name    = labeled_entry(grid, 0, 0, "Name",                "e.g. Snake Game")
                amta_fill_gname   = labeled_entry(grid, 0, 1, "Generic Name",        "e.g. Game")
                amta_fill_comment = labeled_entry(grid, 1, 0, "Comment / Description","e.g. A fun snake game")

                # Category dropdown
                ctk.CTkLabel(grid, text="Category", text_color=clr_dim, font=("Share Tech Mono", 12)).grid(row=2, column=1, sticky="w", padx=(8, 0), pady=(4, 0))
                amta_category = ctk.CTkComboBox(grid, font=("Share Tech Mono", 12),
                    values=["Game","AudioVideo","Development","Education","Graphics","Network","Office","System","Utility"])
                amta_category.set("Game")
                amta_category.grid(row=3, column=1, sticky="ew", padx=(8, 0), pady=(2, 4))

                # ── Checkboxes ──
                check_row = ctk.CTkFrame(amta_frame, fg_color="transparent")
                check_row.pack(anchor="w", pady=(0, 10))
                var_terminal = ctk.BooleanVar(value=False)
                var_startup  = ctk.BooleanVar(value=True)
                ctk.CTkCheckBox(check_row, text="Terminal",       variable=var_terminal, font=("Share Tech Mono", 13)).pack(side="left", padx=(0, 20))
                ctk.CTkCheckBox(check_row, text="StartupNotify", variable=var_startup,  font=("Share Tech Mono", 13)).pack(side="left")

                # ── Start button ──
                def run_amta():
                    appimage_path = amta_fill_amta_file.get().strip()
                    icon_path     = amta_fill_amta_img.get().strip()
                    name          = amta_fill_name.get().strip()
                    generic_name  = amta_fill_gname.get().strip()
                    comment       = amta_fill_comment.get().strip()
                    category      = amta_category.get().strip()
                    terminal      = "true" if var_terminal.get() else "false"
                    startup       = "true" if var_startup.get() else "false"

                    if not appimage_path or not name:
                        ctk.CTkToplevel(amta_win).title("Please fill in at least the AppImage path and Name.")
                        return

                    desktop_content = (
                        f"[Desktop Entry]\n"
                        f"Name={name}\n"
                        f"GenericName={generic_name}\n"
                        f"Comment={comment}\n"
                        f"Exec={appimage_path}\n"
                        f"Icon={icon_path}\n"
                        f"Terminal={terminal}\n"
                        f"Type=Application\n"
                        f"Categories={category};\n"
                        f"StartupNotify={startup}\n"
                    )
                    desktop_path = f"/home/{username}/.local/share/applications/{name.replace(' ', '_')}.desktop"
                    try:
                        os.makedirs(os.path.dirname(desktop_path), exist_ok=True)
                        with open(desktop_path, "w") as f:
                            f.write(desktop_content)
                        sub.run(["chmod", "+x", appimage_path])
                    except Exception as e:
                        print(f"Error: {e}")

                ctk.CTkButton(amta_frame, text="Start", fg_color=clr_green, hover_color=clr_green_h,
                    font=("Share Tech Mono", 14), height=38, command=run_amta).pack(fill="x", pady=(0, 14))

                # ── Bottom bar ──
                bottom_bar = ctk.CTkFrame(amta_win, corner_radius=0, height=60, fg_color=acc_color)
                bottom_bar.pack(side="bottom", fill="x")
                bottom_bar.pack_propagate(False)
                ctk.CTkButton(bottom_bar, text="Back",  width=90, height=36, corner_radius=50, fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border, command=lambda: amta_win.destroy()).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar, text="Home",  width=90, height=36, corner_radius=50, fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border, command=lambda: amta_win.destroy()).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar, text="Help",  width=90, height=36, corner_radius=50, fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border, text_color="white", command=lambda: show_help(win, "appimage")).pack(side="left", padx=(60, 0), pady=12)
                    
            


            # ── FileSystem Manager Window ──
            def toFS():
                fs_win = ctk.CTkToplevel(win)
                fs_win.title("FileSystem Manager")
                fs_win.geometry(f"{geometry[0]}x{geometry[1]}")
                fs_win.resizable(False, False)

                # ── State ──
                current_path = [stg.get("QuickSettings", "start_directory", fallback=os.path.expanduser("~"))]

                # ── Main frame ──
                fs_frame = ctk.CTkFrame(fs_win, fg_color="transparent")
                fs_frame.pack(fill="both", expand=True)

                # ── Title ──
                ctk.CTkLabel(fs_frame, text="FileSystem Manager", text_color=acc_color,
                    font=("Share Tech Mono", 24, "bold", "italic")).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(fs_frame, text="Control the WHOLE FILESYSTEM With ADMIN Access",
                    text_color=clr_dim, font=("Share Tech Mono", 11, "italic")).pack(anchor="w", padx=15)

                # ── Path bar ──
                path_bar = ctk.CTkFrame(fs_frame, fg_color="transparent")
                path_bar.pack(fill="x", padx=15, pady=(6, 4))
                ctk.CTkLabel(path_bar, text="Path:", font=("Share Tech Mono", 12), text_color=acc_color).pack(side="left", padx=(0, 6))
                path_entry = ctk.CTkEntry(path_bar, font=("Share Tech Mono", 12), width=380)
                path_entry.insert(0, current_path[0])
                path_entry.pack(side="left", expand=True, fill="x", padx=(0, 8))
                ctk.CTkButton(path_bar, text="Go", width=50, fg_color=acc_color,
                    command=lambda: navigate_to(path_entry.get().strip())).pack(side="left", padx=(0, 6))
                ctk.CTkButton(path_bar, text="↑ Up", width=60, fg_color=acc_active, hover_color=acc_hover,
                    command=lambda: navigate_to(str(os.path.dirname(current_path[0])))).pack(side="left")

                # ── Search bar (if enabled in settings) ──
                fs_search_enabled = stg.getboolean("System", "fs_search_mode", fallback=False)
                search_entry = [None]
                if fs_search_enabled:
                    search_bar = ctk.CTkFrame(fs_frame, fg_color="transparent")
                    search_bar.pack(fill="x", padx=15, pady=(0, 4))
                    ctk.CTkLabel(search_bar, text="Search:", font=("Share Tech Mono", 12), text_color=acc_color).pack(side="left", padx=(0, 6))
                    search_entry[0] = ctk.CTkEntry(search_bar, font=("Share Tech Mono", 11), placeholder_text="filename...")
                    search_entry[0].pack(side="left", fill="x", expand=True, padx=(0, 8))
                    def do_fs_search(event=None):
                        query = search_entry[0].get().strip().lower()
                        for w in list_frame.winfo_children():
                            w.destroy()
                        if not query:
                            refresh_list()
                            return
                        try:
                            entries = sorted(os.listdir(current_path[0]))
                        except PermissionError:
                            return
                        matches = [n for n in entries if query in n.lower()]
                        if not matches:
                            ctk.CTkLabel(list_frame, text="No results.", text_color=clr_dim,
                                font=("Share Tech Mono", 11, "italic")).pack(anchor="w")
                            return
                        for name in matches:
                            full = os.path.join(current_path[0], name)
                            is_dir = os.path.isdir(full)
                            icon = "📁 " if is_dir else "📄 "
                            row = ctk.CTkFrame(list_frame, fg_color="transparent")
                            row.pack(fill="x", pady=1)
                            lbl = ctk.CTkLabel(row, text=icon + name,
                                font=("Share Tech Mono", 12, "bold" if is_dir else "normal"),
                                text_color=acc_color if is_dir else "white", anchor="w")
                            lbl.pack(side="left", fill="x", expand=True)
                            def on_s_click(f=full):
                                selected_path[0] = f
                                selected_label.configure(text=f"Selected: {f}")
                            lbl.bind("<Button-1>", lambda e, fn=on_s_click: fn())
                            row.bind("<Button-1>", lambda e, fn=on_s_click: fn())
                    ctk.CTkButton(search_bar, text="🔍", width=40, fg_color=acc_color,
                        command=do_fs_search).pack(side="left")
                    search_entry[0].bind("<Return>", do_fs_search)

                # ── File list ──
                list_frame = ctk.CTkScrollableFrame(fs_frame, fg_color="transparent", width=550, height=220,
                    scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h,
                    border_width=2, border_color=acc_color)
                list_frame.pack(padx=15, pady=(0, 4), fill="x")

                # ── Selected file label ──
                selected_label = ctk.CTkLabel(fs_frame, text="Selected: None",
                    text_color=clr_dim, font=("Share Tech Mono", 11, "italic"), anchor="w")
                selected_label.pack(anchor="w", padx=15, pady=(0, 4))

                # ── Operation buttons ──
                btn_frame = ctk.CTkFrame(fs_frame, fg_color="transparent")
                btn_frame.pack(fill="x", padx=15, pady=(0, 8))
                ctk.CTkButton(btn_frame, text="New File",   width=90,  height=34, fg_color=clr_green, hover_color=clr_green_h, command=lambda: op_window("new_file")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="New Folder", width=100, height=34, fg_color=clr_green, hover_color=clr_green_h, command=lambda: op_window("new_folder")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="Rename",     width=80,  height=34, fg_color=acc_color,  hover_color=acc_hover, command=lambda: op_window("rename")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="Move",       width=70,  height=34, fg_color=acc_color,  hover_color=acc_hover, command=lambda: op_window("move")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="Copy",       width=70,  height=34, fg_color=clr_grey,  hover_color=clr_grey_h, command=lambda: op_window("copy")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="Delete",     width=75,  height=34, fg_color=clr_red,  hover_color=clr_red_h, command=lambda: op_window("delete")).pack(side="left", padx=(0, 6))
                ctk.CTkButton(btn_frame, text="Info",       width=60,  height=34, fg_color=clr_grey,  hover_color=clr_grey_h, command=lambda: op_window("info")).pack(side="left")

                # ── Bottom bar ──
                bottom_bar_fs = ctk.CTkFrame(fs_win, corner_radius=0, height=60, fg_color=acc_color)
                bottom_bar_fs.pack(side="bottom", fill="x")
                bottom_bar_fs.pack_propagate(False)
                ctk.CTkButton(bottom_bar_fs, text="Back", width=90, height=36, corner_radius=50,
                    fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border,
                    command=lambda: fs_win.destroy()).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar_fs, text="Home", width=90, height=36, corner_radius=50,
                    fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border,
                    command=lambda: fs_win.destroy()).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar_fs, text="Help", width=90, height=36, corner_radius=50,
                    fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border,
                    text_color="white", command=lambda: show_help(win, "filesystem")).pack(side="left", padx=(60, 0), pady=12)

                # ── Helpers ──
                selected_path = [None]

                def refresh_list():
                    for w in list_frame.winfo_children():
                        w.destroy()
                    try:
                        entries = sorted(os.listdir(current_path[0]))
                    except PermissionError:
                        ctk.CTkLabel(list_frame, text="Permission denied.", text_color="#c00000",
                            font=("Share Tech Mono", 11, "italic")).pack(anchor="w")
                        return
                    if not entries:
                        ctk.CTkLabel(list_frame, text="(empty folder)", text_color=clr_dim,
                            font=("Share Tech Mono", 11, "italic")).pack(anchor="w")
                        return
                    for name in entries:
                        full = os.path.join(current_path[0], name)
                        is_dir = os.path.isdir(full)
                        icon = "📁 " if is_dir else "📄 "
                        row = ctk.CTkFrame(list_frame, fg_color="transparent")
                        row.pack(fill="x", pady=1)
                        lbl = ctk.CTkLabel(row, text=icon + name,
                            font=("Share Tech Mono", 12, "bold" if is_dir else "normal"),
                            text_color=acc_color if is_dir else "white", anchor="w")
                        lbl.pack(side="left", fill="x", expand=True)
                        def on_click(f=full, d=is_dir):
                            selected_path[0] = f
                            selected_label.configure(text=f"Selected: {f}")
                            if d:
                                navigate_to(f)
                        lbl.bind("<Button-1>", lambda e, fn=on_click: fn())
                        row.bind("<Button-1>", lambda e, fn=on_click: fn())

                def navigate_to(path):
                    path = os.path.expanduser(path)
                    if os.path.isdir(path):
                        current_path[0] = path
                        path_entry.delete(0, "end")
                        path_entry.insert(0, path)
                        if search_entry[0]:
                            search_entry[0].delete(0, "end")
                        refresh_list()

                # ── Operation child windows ──
                def op_window(op):
                    import shutil, datetime
                    src = selected_path[0]
                    base = current_path[0]

                    op_win = ctk.CTkToplevel(fs_win)
                    op_win.resizable(False, False)
                    op_win.after(100, op_win.grab_set)

                    titles = {
                        "new_file": "New File", "new_folder": "New Folder",
                        "rename": "Rename", "move": "Move",
                        "copy": "Copy", "delete": "Delete", "info": "Info"
                    }
                    op_win.title(titles.get(op, op))
                    op_win.geometry("420x260")

                    f = ctk.CTkFrame(op_win, fg_color="transparent")
                    f.pack(fill="both", expand=True, padx=20, pady=16)

                    ctk.CTkLabel(f, text=titles.get(op, op), font=("Share Tech Mono", 18, "bold"),
                        text_color=acc_color).pack(anchor="w", pady=(0, 10))

                    result_lbl = ctk.CTkLabel(f, text="", font=("Share Tech Mono", 11),
                        text_color="white", wraplength=370, justify="left")

                    def show(msg, color="white"):
                        win.after(0, lambda: result_lbl.configure(text=msg, text_color=color))
                        win.after(0, refresh_list)

                    # ── New File ──
                    if op == "new_file":
                        op_win.geometry("420x220")
                        ctk.CTkLabel(f, text="File name:", font=("Share Tech Mono", 12), text_color=acc_color).pack(anchor="w")
                        e = ctk.CTkEntry(f, font=("Share Tech Mono", 12), placeholder_text="example.txt")
                        e.pack(fill="x", pady=(0, 8))
                        result_lbl.pack(anchor="w")
                        def do(e=e, base=base):
                            name = e.get().strip() or "new_file.txt"
                            target = os.path.join(base, name)
                            def _r(target=target):
                                try:
                                    open(target, "a").close()
                                    show(f"✔ Created: {target}", "#48aa30")
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="Create", fg_color=clr_green, hover_color=clr_green_h, command=do).pack(fill="x")

                    # ── New Folder ──
                    elif op == "new_folder":
                        op_win.geometry("420x220")
                        ctk.CTkLabel(f, text="Folder name:", font=("Share Tech Mono", 12), text_color=acc_color).pack(anchor="w")
                        e = ctk.CTkEntry(f, font=("Share Tech Mono", 12), placeholder_text="new_folder")
                        e.pack(fill="x", pady=(0, 8))
                        result_lbl.pack(anchor="w")
                        def do(e=e, base=base):
                            name = e.get().strip() or "new_folder"
                            target = os.path.join(base, name)
                            def _r(target=target):
                                try:
                                    os.makedirs(target, exist_ok=True)
                                    show(f"✔ Created: {target}", "#48aa30")
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="Create", fg_color=clr_green, hover_color=clr_green_h, command=do).pack(fill="x")

                    # ── Rename ──
                    elif op == "rename":
                        op_win.geometry("420x240")
                        ctk.CTkLabel(f, text=f"Renaming: {os.path.basename(src) if src else '—'}", font=("Share Tech Mono", 11), text_color=clr_dim).pack(anchor="w")
                        ctk.CTkLabel(f, text="New name:", font=("Share Tech Mono", 12), text_color=acc_color).pack(anchor="w", pady=(6,0))
                        e = ctk.CTkEntry(f, font=("Share Tech Mono", 12))
                        e.pack(fill="x", pady=(0, 8))
                        result_lbl.pack(anchor="w")
                        def do(e=e, src=src):
                            if not src: show("✘ Select a file first.", "#c00000"); return
                            new_name = e.get().strip()
                            if not new_name: show("✘ Enter a new name.", "#c00000"); return
                            dest = os.path.join(os.path.dirname(src), new_name)
                            def _r(src=src, dest=dest):
                                try:
                                    os.rename(src, dest)
                                    show(f"✔ Renamed to: {new_name}", "#48aa30")
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="Rename", fg_color=acc_color, hover_color=acc_hover, command=do).pack(fill="x")

                    # ── Move ──
                    elif op == "move":
                        ctk.CTkLabel(f, text=f"Moving: {os.path.basename(src) if src else '—'}", font=("Share Tech Mono", 11), text_color=clr_dim).pack(anchor="w")
                        ctk.CTkLabel(f, text="Destination folder:", font=("Share Tech Mono", 12), text_color=acc_color).pack(anchor="w", pady=(6,0))
                        dr = ctk.CTkFrame(f, fg_color="transparent"); dr.pack(fill="x", pady=(0,8))
                        e = ctk.CTkEntry(dr, font=("Share Tech Mono", 12)); e.pack(side="left", fill="x", expand=True, padx=(0,6))
                        ctk.CTkButton(dr, text="Browse", width=75, fg_color=acc_color,
                            command=lambda e=e: (e.delete(0,"end") or e.insert(0, ctk.filedialog.askdirectory(initialdir=base) or e.get()))).pack(side="left")
                        result_lbl.pack(anchor="w")
                        def do(e=e, src=src):
                            if not src: show("✘ Select a file first.", "#c00000"); return
                            dest = e.get().strip()
                            if not dest: show("✘ Enter destination.", "#c00000"); return
                            def _r(src=src, dest=dest):
                                try:
                                    shutil.move(src, dest)
                                    show(f"✔ Moved to: {dest}", "#48aa30")
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="Move", fg_color=acc_color, hover_color=acc_hover, command=do).pack(fill="x")

                    # ── Copy ──
                    elif op == "copy":
                        ctk.CTkLabel(f, text=f"Copying: {os.path.basename(src) if src else '—'}", font=("Share Tech Mono", 11), text_color=clr_dim).pack(anchor="w")
                        ctk.CTkLabel(f, text="Destination folder:", font=("Share Tech Mono", 12), text_color=acc_color).pack(anchor="w", pady=(6,0))
                        dr = ctk.CTkFrame(f, fg_color="transparent"); dr.pack(fill="x", pady=(0,8))
                        e = ctk.CTkEntry(dr, font=("Share Tech Mono", 12)); e.pack(side="left", fill="x", expand=True, padx=(0,6))
                        ctk.CTkButton(dr, text="Browse", width=75, fg_color=acc_color,
                            command=lambda e=e: (e.delete(0,"end") or e.insert(0, ctk.filedialog.askdirectory(initialdir=base) or e.get()))).pack(side="left")
                        result_lbl.pack(anchor="w")
                        def do(e=e, src=src):
                            if not src: show("✘ Select a file first.", "#c00000"); return
                            dest = e.get().strip()
                            if not dest: show("✘ Enter destination.", "#c00000"); return
                            def _r(src=src, dest=dest):
                                try:
                                    if os.path.isdir(src):
                                        shutil.copytree(src, os.path.join(dest, os.path.basename(src)))
                                    else:
                                        shutil.copy2(src, dest)
                                    show(f"✔ Copied to: {dest}", "#48aa30")
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="Copy", fg_color=clr_grey, hover_color=clr_grey_h, command=do).pack(fill="x")

                    # ── Delete ──
                    elif op == "delete":
                        op_win.geometry("420x200")
                        ctk.CTkLabel(f, text=f"Are you sure you want to delete:",
                            font=("Share Tech Mono", 12), text_color="white").pack(anchor="w")
                        ctk.CTkLabel(f, text=src if src else "Nothing selected",
                            font=("Share Tech Mono", 11, "bold"), text_color="#c00000", wraplength=370).pack(anchor="w", pady=(4,10))
                        result_lbl.pack(anchor="w")
                        def do(src=src):
                            if not src: show("✘ Select a file first.", "#c00000"); return
                            def _r(src=src):
                                try:
                                    if os.path.isdir(src):
                                        shutil.rmtree(src)
                                    else:
                                        os.remove(src)
                                    show(f"✔ Deleted.", "#48aa30")
                                    selected_path[0] = None
                                    win.after(0, lambda: selected_label.configure(text="Selected: None"))
                                except Exception as ex: show(f"✘ {ex}", "#c00000")
                            trd.Thread(target=_r, daemon=True).start()
                        ctk.CTkButton(f, text="⚠ Confirm Delete", fg_color=clr_red, hover_color=clr_red_h, command=do).pack(fill="x")

                    # ── Info ──
                    elif op == "info":
                        op_win.geometry("420x320")
                        if src and os.path.exists(src):
                            import pwd, grp
                            stat = os.stat(src)
                            is_dir = os.path.isdir(src)
                            ext = os.path.splitext(src)[1] if not is_dir else "—"
                            kind = "Directory" if is_dir else f"File ({ext if ext else 'no extension'})"
                            size = stat.st_size
                            mtime = datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                            try:
                                owner = pwd.getpwuid(stat.st_uid).pw_name
                            except KeyError:
                                owner = str(stat.st_uid)
                            try:
                                group = grp.getgrgid(stat.st_gid).gr_name
                            except KeyError:
                                group = str(stat.st_gid)
                            if is_dir:
                                try:
                                    contents = os.listdir(src)
                                    file_count = sum(1 for x in contents if os.path.isfile(os.path.join(src, x)))
                                    dir_count  = sum(1 for x in contents if os.path.isdir(os.path.join(src, x)))
                                    count_str  = f"{file_count} file(s), {dir_count} folder(s)"
                                except PermissionError:
                                    count_str = "Permission denied"
                                info_text = (f"Name:     {os.path.basename(src)}\n"
                                             f"Type:     {kind}\n"
                                             f"Contains: {count_str}\n"
                                             f"Size:     {size:,} bytes\n"
                                             f"Modified: {mtime}\n"
                                             f"Owner:    {owner}\n"
                                             f"Group:    {group}\n"
                                             f"Path:     {src}")
                            else:
                                info_text = (f"Name:     {os.path.basename(src)}\n"
                                             f"Type:     {kind}\n"
                                             f"Size:     {size:,} bytes\n"
                                             f"Modified: {mtime}\n"
                                             f"Owner:    {owner}\n"
                                             f"Group:    {group}\n"
                                             f"Path:     {src}")
                        else:
                            info_text = "No file selected or file not found."
                        ctk.CTkTextbox(f, font=("Share Tech Mono", 11), height=200).pack(fill="x", pady=(0,8))
                        tb = f.winfo_children()[-1]
                        tb.insert("end", info_text)
                        tb.configure(state="disabled")
                        ctk.CTkButton(f, text="Close", fg_color=clr_grey, hover_color=clr_grey_h, command=op_win.destroy).pack(fill="x")

                # initial load
                refresh_list()


            # ── Settings ──
            def toSettings():
                import configparser

                def save_stg():
                    with open(stg_path, "w") as f:
                        stg.write(f)

                stg_win = ctk.CTkToplevel(win)
                stg_win.title("Settings - T.U.I")
                stg_win.geometry(f"{geometry[0]}x{geometry[1]}")
                stg_win.resizable(False, False)
                stg_win.after(100, stg_win.grab_set)

                # ── Tab bar ──
                tab_bar = ctk.CTkFrame(stg_win, fg_color=acc_color, height=44, corner_radius=0)
                tab_bar.pack(fill="x")
                tab_bar.pack_propagate(False)

                content = ctk.CTkFrame(stg_win, fg_color="transparent")
                content.pack(fill="both", expand=True)

                tab_frames  = {}
                tab_buttons = {}
                tab_names   = ["Quick Settings", "System", "Colors & Themes", "About"]

                # Build frames first
                for tab in tab_names:
                    tab_frames[tab] = ctk.CTkScrollableFrame(content, fg_color="transparent",
                        scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h)

                # Build tab buttons
                for tab in tab_names:
                    b = ctk.CTkButton(tab_bar, text=tab, width=130, height=44, corner_radius=0,
                        fg_color="transparent", hover_color=acc_active, font=("Share Tech Mono", 12),
                        command=lambda t=tab: show_tab(t))
                    b.pack(side="left")
                    tab_buttons[tab] = b

                def show_tab(name):
                    for f in tab_frames.values():
                        f.pack_forget()
                    tab_frames[name].pack(fill="both", expand=True, padx=18, pady=14)
                    for n, b in tab_buttons.items():
                        b.configure(
                            fg_color=acc_active if n == name else "transparent",
                            font=("Share Tech Mono", 12, "bold") if n == name else ("Share Tech Mono", 12)
                        )

                # ════════════════════════════════
                # TAB 1 — Quick Settings
                # ════════════════════════════════
                qs = tab_frames["Quick Settings"]

                def section(parent, text):
                    ctk.CTkLabel(parent, text=text, font=("Share Tech Mono", 13, "bold"),
                        text_color=acc_color).pack(anchor="w", pady=(12, 2))
                    ctk.CTkFrame(parent, height=2, fg_color=acc_color).pack(fill="x", pady=(0, 8))

                # Theme mode
                section(qs, "Theme Mode")
                theme_var = ctk.StringVar(value=stg.get("QuickSettings", "theme_mode", fallback="dark"))
                theme_row = ctk.CTkFrame(qs, fg_color="transparent")
                theme_row.pack(anchor="w")
                def on_theme_change(var=theme_var):
                    stg.set("QuickSettings", "theme_mode", var.get())
                    ctk.set_appearance_mode(var.get())
                    save_stg()
                for mode in ["dark", "light", "system"]:
                    ctk.CTkRadioButton(theme_row, text=mode.capitalize(), variable=theme_var, value=mode,
                        font=("Share Tech Mono", 12), command=on_theme_change).pack(side="left", padx=(0, 18))

                # Accent color
                section(qs, "Accent Color")
                acc_row = ctk.CTkFrame(qs, fg_color="transparent")
                acc_row.pack(fill="x", pady=(0, 4))
                acc_entry = ctk.CTkEntry(acc_row, font=("Share Tech Mono", 12), width=160,
                    placeholder_text="#5691e9")
                acc_entry.insert(0, acc_color)
                acc_entry.pack(side="left", padx=(0, 10))
                acc_preview = ctk.CTkFrame(acc_row, width=36, height=36, corner_radius=8,
                    fg_color=acc_color)
                acc_preview.pack(side="left", padx=(0, 10))
                acc_preview.pack_propagate(False)

                def pick_color():
                    if _AskColor:
                        picked = _AskColor(color=acc_entry.get()).get()
                    else:
                        import tkinter.colorchooser as cc
                        picked = cc.askcolor(color=acc_entry.get(), title="Pick Accent Color")[1]
                    if picked:
                        acc_entry.delete(0, "end")
                        acc_entry.insert(0, picked)
                        acc_preview.configure(fg_color=picked)

                def apply_accent():
                    val = acc_entry.get().strip()
                    if not val.startswith("#") or len(val) not in (4, 7):
                        return
                    stg.set("QuickSettings", "accent_color", val)
                    acc_preview.configure(fg_color=val)
                    save_stg()

                ctk.CTkButton(acc_row, text="🎨 Pick", width=80, fg_color=acc_color,
                    command=pick_color).pack(side="left", padx=(0, 8))
                ctk.CTkButton(acc_row, text="Apply", width=70, fg_color=clr_green, hover_color=clr_green_h,
                    command=apply_accent).pack(side="left")
                ctk.CTkLabel(qs, text="Restart TUI to apply accent color changes.",
                    text_color=clr_dim, font=("Share Tech Mono", 10, "italic")).pack(anchor="w", pady=(0, 4))

                # Start directory
                section(qs, "FileSystem Start Directory")
                dir_row = ctk.CTkFrame(qs, fg_color="transparent")
                dir_row.pack(fill="x")
                dir_entry = ctk.CTkEntry(dir_row, font=("Share Tech Mono", 11),
                    placeholder_text=f"/home/{username}")
                dir_entry.insert(0, stg.get("QuickSettings", "start_directory", fallback=f"/home/{username}"))
                dir_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
                def save_dir():
                    stg.set("QuickSettings", "start_directory", dir_entry.get().strip())
                    save_stg()
                ctk.CTkButton(dir_row, text="Save", width=70, fg_color=clr_green, hover_color=clr_green_h,
                    command=save_dir).pack(side="left")

                # ════════════════════════════════
                # TAB 2 — System
                # ════════════════════════════════
                sys_tab = tab_frames["System"]

                section(sys_tab, "FileSystem Manager")
                fs_search_var = ctk.BooleanVar(value=stg.getboolean("System", "fs_search_mode", fallback=False))
                def on_fs_search(var=fs_search_var):
                    stg.set("System", "fs_search_mode", str(var.get()).lower())
                    save_stg()
                ctk.CTkSwitch(sys_tab, text="Enable Search Mode", variable=fs_search_var,
                    font=("Share Tech Mono", 12), onvalue=True, offvalue=False,
                    command=on_fs_search).pack(anchor="w", pady=(0, 10))

                section(sys_tab, "Performance")
                cpu_mem_var = ctk.BooleanVar(value=stg.getboolean("System", "show_cpu_memory", fallback=False))
                def on_cpu_mem(var=cpu_mem_var):
                    stg.set("System", "show_cpu_memory", str(var.get()).lower())
                    save_stg()
                ctk.CTkSwitch(sys_tab, text="Show Memory & CPU Usage", variable=cpu_mem_var,
                    font=("Share Tech Mono", 12), onvalue=True, offvalue=False,
                    command=on_cpu_mem).pack(anchor="w", pady=(0, 10))

                section(sys_tab, "Driver Fixer — After Restart Required")
                driver_var = ctk.StringVar(value=stg.get("System", "after_driver_fix", fallback="Ask"))
                driver_row = ctk.CTkFrame(sys_tab, fg_color="transparent")
                driver_row.pack(anchor="w")
                def on_driver_change(var=driver_var):
                    stg.set("System", "after_driver_fix", var.get())
                    save_stg()
                for opt in ["Ask", "Restart", "Do Nothing"]:
                    ctk.CTkRadioButton(driver_row, text=opt, variable=driver_var, value=opt,
                        font=("Share Tech Mono", 12), command=on_driver_change).pack(side="left", padx=(0, 18))

                # ════════════════════════════════
                # TAB 3 — Colors & Themes
                # ════════════════════════════════
                ct = tab_frames["Colors & Themes"]
                section(ct, "Colors & Themes")
                ctk.CTkLabel(ct, text="Full theme customization coming in a future update.",
                    text_color=clr_dim, font=("Share Tech Mono", 12, "italic")).pack(anchor="w", pady=(0, 10))
                ctk.CTkLabel(ct, text="For now, use Quick Settings → Accent Color to change the main color.",
                    text_color=clr_dim, font=("Share Tech Mono", 11)).pack(anchor="w")

                # ════════════════════════════════
                # TAB 4 — About
                # ════════════════════════════════
                ab = tab_frames["About"]
                section(ab, "About T.U.I")
                ctk.CTkLabel(ab, text="T.U.I  |  Terminal.User.Interface",
                    font=("Share Tech Mono", 18, "bold"), text_color=acc_color).pack(anchor="w", pady=(0, 4))
                ctk.CTkLabel(ab, text="A Linux desktop utility app built with Python & CustomTkinter.",
                    font=("Share Tech Mono", 12), text_color="white").pack(anchor="w")
                ctk.CTkLabel(ab, text="Version: 1.0.0  •  Linux only",
                    font=("Share Tech Mono", 11), text_color=clr_dim).pack(anchor="w", pady=(8, 0))
                ctk.CTkLabel(ab, text="Config:  ~/.TUI/conf/",
                    font=("Share Tech Mono", 11), text_color=clr_dim).pack(anchor="w", pady=(2, 0))

                section(ab, "Built With")
                for lib in [("Python 3", "Language"), ("CustomTkinter", "GUI Framework"),
                            ("configparser", "Settings"), ("subprocess / threading", "System ops")]:
                    row = ctk.CTkFrame(ab, fg_color="transparent")
                    row.pack(fill="x", pady=2)
                    ctk.CTkLabel(row, text=f"  {lib[0]}", font=("Share Tech Mono", 12, "bold"),
                        text_color="white", width=200, anchor="w").pack(side="left")
                    ctk.CTkLabel(row, text=lib[1], font=("Share Tech Mono", 11),
                        text_color=clr_dim, anchor="w").pack(side="left")

                # ── Bottom bar ──
                bottom_bar_stg = ctk.CTkFrame(stg_win, corner_radius=0, height=60, fg_color=acc_color)
                bottom_bar_stg.pack(side="bottom", fill="x")
                bottom_bar_stg.pack_propagate(False)
                ctk.CTkButton(bottom_bar_stg, text="Back", width=90, height=36, corner_radius=50,
                    fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border,
                    command=stg_win.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar_stg, text="Home", width=90, height=36, corner_radius=50,
                    fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border,
                    command=stg_win.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom_bar_stg, text="Help", width=90, height=36, corner_radius=50,
                    fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border,
                    text_color="white", command=lambda: show_help(win, "settings")).pack(side="left", padx=(60, 0), pady=12)

                show_tab("Quick Settings")

            # ── Help dialog ──
            def show_help(parent, page="home"):
                help_content = {
                    "home": [
                        ("Package Manager", "Install, remove & check APT/Flatpak/AppImage packages."),
                        ("FileSystem",      "Browse, create, rename, move, copy & delete files."),
                        ("System",          "Driver Fixer and other system tools."),
                        ("GNU/GRUB",        "Safely modify your bootloader."),
                        ("Settings",        "Customise theme, accent color & behaviour."),
                    ],
                    "pkg": [
                        ("APT",             "Install, remove & check packages from Ubuntu repositories."),
                        ("Flathub",         "Search and install Flatpak apps from Flathub."),
                        ("AppImage >>> APP","Convert an AppImage into a proper desktop app launcher."),
                    ],
                    "apt": [
                        ("Install", "Type a package name and select Install to install it via APT."),
                        ("Remove",  "Type a package name and select Remove to uninstall it."),
                        ("Version", "Type a package name and select Version to see its info."),
                        ("Tip",     "Package names are case-sensitive. e.g. 'vlc', 'firefox', 'git'."),
                    ],
                    "flathub": [
                        ("Search Tab",  "Search for apps by name. Results show the App ID you need."),
                        ("Flatpak Tab", "Paste the App ID from Search to install, remove or check version."),
                        ("Tip",         "App IDs look like 'com.spotify.Client' or 'org.gimp.GIMP'."),
                    ],
                    "appimage": [
                        ("AppImage File", "Browse and select your .AppImage file."),
                        ("Icon",          "Browse and select an icon (.png, .svg, .jpg, .ico)."),
                        ("App Name",      "Enter the name that will appear in your app launcher."),
                        ("Convert",       "Click Convert to make the AppImage launchable from your menu."),
                    ],
                    "filesystem": [
                        ("Navigation",  "Click folders to enter them. Use ↑ Up to go back a level."),
                        ("Select",      "Click any file or folder to select it before using an operation."),
                        ("Operations",  "New File, New Folder, Rename, Move, Copy, Delete, Info."),
                        ("Search",      "Enable Search Mode in Settings to filter files by name."),
                        ("Info",        "Shows file type, size, owner, group and modification date."),
                    ],
                    "system": [
                        ("Drivers",  "View hardware info, check & auto-install drivers."),
                        ("Apps",     "Browse running processes, terminate apps, view info & manual."),
                        ("OS",       "Check kernel version, stability, OS info & list users."),
                    ],
                    "grub": [
                        ("GNU/GRUB", "Coming soon — safely modify your bootloader and boot entries."),
                    ],
                    "settings": [
                        ("Quick Settings", "Change theme mode, accent color and FileSystem start directory."),
                        ("System",         "Toggle search mode, CPU/RAM display and driver restart behaviour."),
                        ("Colors & Themes","Full customization coming in v2."),
                        ("About",          "Version info, config path and library credits."),
                    ],
                    "cheatsheet": [
                        ("Simple",   "18 essential commands — ls, cd, apt, sudo, reboot and more."),
                        ("Advanced", "23 power-user commands — grep, chmod, ssh, systemctl and more."),
                        ("Copy",     "Click any row to copy the example command to your clipboard."),
                    ],
                }
                items = help_content.get(page, help_content["home"])
                page_titles = {
                    "home": "T.U.I Help", "pkg": "Package Manager Help", "apt": "APT Help",
                    "flathub": "Flathub Help", "appimage": "AppImage Help",
                    "filesystem": "FileSystem Help", "system": "System Help",
                    "grub": "GNU/GRUB Help", "settings": "Settings Help",
                    "cheatsheet": "Cheatsheet Help"
                }
                h = ctk.CTkToplevel(parent)
                h.title(page_titles.get(page, "Help"))
                h.geometry("440x" + str(80 + len(items) * 52))
                h.resizable(False, False)
                h.after(100, h.grab_set)
                f = ctk.CTkFrame(h, fg_color="transparent")
                f.pack(fill="both", expand=True, padx=20, pady=16)
                ctk.CTkLabel(f, text=page_titles.get(page, "Help"),
                    font=("Share Tech Mono", 18, "bold"), text_color=acc_color).pack(anchor="w")
                ctk.CTkFrame(f, height=2, fg_color=acc_color).pack(fill="x", pady=(2, 8))
                for t, d in items:
                    ctk.CTkLabel(f, text=f"• {t}: {d}", font=("Share Tech Mono", 11),
                        text_color="white", wraplength=390, justify="left").pack(anchor="w", pady=2)
                ctk.CTkButton(f, text="Close", fg_color=clr_grey, hover_color=clr_grey_h,
                    command=h.destroy).pack(fill="x", pady=(12, 0))

            # ── System ──
            def toSystem():
                sys_win = ctk.CTkToplevel(win)
                sys_win.title("System")
                sys_win.geometry(f"{geometry[0]}x{geometry[1]}")
                sys_win.resizable(False, False)

                sys_main    = ctk.CTkFrame(sys_win, fg_color="transparent")
                sys_drivers = ctk.CTkFrame(sys_win, fg_color="transparent")
                sys_apps    = ctk.CTkFrame(sys_win, fg_color="transparent")
                sys_os      = ctk.CTkFrame(sys_win, fg_color="transparent")

                sys_bar = ctk.CTkFrame(sys_win, corner_radius=0, height=60, fg_color=acc_color)
                sys_bar.pack(side="bottom", fill="x")
                sys_bar.pack_propagate(False)
                sys_back_btn = ctk.CTkButton(sys_bar, text="Back", width=90, height=36, corner_radius=50,
                    fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border,
                    command=sys_win.destroy)
                sys_back_btn.pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(sys_bar, text="Home", width=90, height=36, corner_radius=50,
                    fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border,
                    command=sys_win.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(sys_bar, text="Help", width=90, height=36, corner_radius=50,
                    fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border,
                    text_color="white", command=lambda: show_help(win, "system")).pack(side="left", padx=(60, 0), pady=12)
                if cpu_mem_enabled:
                    try: _make_cpu_label(sys_bar)
                    except NameError: pass

                def show_sys_main():
                    for f in [sys_drivers, sys_apps, sys_os]: f.pack_forget()
                    sys_main.pack(fill="both", expand=True)
                    sys_back_btn.configure(command=sys_win.destroy)

                def show_drivers():
                    sys_main.pack_forget(); sys_apps.pack_forget(); sys_os.pack_forget()
                    sys_drivers.pack(fill="both", expand=True)
                    sys_back_btn.configure(command=show_sys_main)

                def show_apps():
                    sys_main.pack_forget(); sys_drivers.pack_forget(); sys_os.pack_forget()
                    sys_apps.pack(fill="both", expand=True)
                    sys_back_btn.configure(command=show_sys_main)

                def show_os():
                    sys_main.pack_forget(); sys_drivers.pack_forget(); sys_apps.pack_forget()
                    sys_os.pack(fill="both", expand=True)
                    sys_back_btn.configure(command=show_sys_main)

                # ── Main selector ──
                ctk.CTkLabel(sys_main, text="System", font=("Share Tech Mono", 24, "bold", "italic"),
                    text_color=acc_color).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(sys_main, text="System Tools & Information",
                    font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15)
                btn_frame = ctk.CTkFrame(sys_main, width=575, height=160,
                    border_color=acc_color, border_width=2, fg_color="transparent")
                btn_frame.place(x=5, y=80)
                btn_frame.pack_propagate(False)
                ctk.CTkButton(btn_frame, width=560, height=40, text="Drivers",
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=show_drivers).pack(pady=(5, 0), anchor="center")
                ctk.CTkButton(btn_frame, width=560, height=40, text="Apps",
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=show_apps).pack(pady=(15, 0), anchor="center")
                ctk.CTkButton(btn_frame, width=560, height=40, text="OS",
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=show_os).pack(pady=(15, 0), anchor="center")

                # ── Drivers ──
                ctk.CTkLabel(sys_drivers, text="Drivers", font=("Share Tech Mono", 22, "bold", "italic"),
                    text_color=acc_color).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(sys_drivers, text="Hardware & Driver Information",
                    font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15, pady=(0,6))

                drv_list = ctk.CTkScrollableFrame(sys_drivers, fg_color="transparent", height=270,
                    scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h,
                    border_width=2, border_color=acc_color)
                drv_list.pack(fill="x", padx=15, pady=(0,6))

                drv_status = ctk.CTkLabel(sys_drivers, text="", font=("Share Tech Mono", 11, "italic"), text_color=clr_dim)
                drv_status.pack(anchor="w", padx=15)

                drv_btn_row = ctk.CTkFrame(sys_drivers, fg_color="transparent")
                drv_btn_row.pack(fill="x", padx=15, pady=(4,0))

                def drv_add_row(label, value, color="white"):
                    row = ctk.CTkFrame(drv_list, fg_color="transparent")
                    row.pack(fill="x", pady=2)
                    ctk.CTkLabel(row, text=label, font=("Share Tech Mono", 11, "bold"),
                        text_color=acc_color, width=180, anchor="w").pack(side="left", padx=(6,0))
                    ctk.CTkLabel(row, text=value, font=("Share Tech Mono", 10),
                        text_color=color, anchor="w").pack(side="left", padx=(8,0), fill="x", expand=True)

                current_view = ["basic"]

                def _do_basic():
                    info = {}
                    try:
                        cpu_raw = sub.run(["grep", "-m1", "model name", "/proc/cpuinfo"], capture_output=True, text=True).stdout
                        info["CPU"] = cpu_raw.split(":")[1].strip() if ":" in cpu_raw else "Unknown"
                        mem_raw = sub.run(["grep", "MemTotal", "/proc/meminfo"], capture_output=True, text=True).stdout
                        if ":" in mem_raw:
                            kb = int(mem_raw.split(":")[1].strip().split()[0])
                            info["RAM"] = f"{kb // 1024} MB  ({kb // (1024*1024)} GB)"
                        else:
                            info["RAM"] = "Unknown"
                        gpu_raw = sub.run(["lspci"], capture_output=True, text=True).stdout
                        gpus = [l.split(":", 2)[-1].strip() for l in gpu_raw.splitlines() if "VGA" in l or "3D" in l or "Display" in l]
                        info["GPU"] = gpus[0] if gpus else "Unknown / Integrated"
                        disk_raw = sub.run(["lsblk", "-d", "-o", "NAME,SIZE,MODEL"], capture_output=True, text=True).stdout
                        disks = [l.strip() for l in disk_raw.splitlines()[1:] if l.strip()]
                        info["Disk(s)"] = "  |  ".join(disks) if disks else "Unknown"
                        nets = [l.split(":", 2)[-1].strip() for l in gpu_raw.splitlines() if "Network" in l or "Ethernet" in l or "Wireless" in l]
                        info["Network"] = nets[0] if nets else "Unknown"
                        info["Kernel"] = sub.run(["uname", "-r"], capture_output=True, text=True).stdout.strip()
                        drv_out = sub.run(["ubuntu-drivers", "list"], capture_output=True, text=True).stdout.strip()
                        info["Recommended Drivers"] = drv_out if drv_out else "✔ All drivers up to date"
                    except Exception as e:
                        info["Error"] = str(e)
                    def _ui():
                        for w in drv_list.winfo_children(): w.destroy()
                        for label, value in info.items():
                            color = clr_green if "✔" in value else ("white" if label != "Recommended Drivers" else clr_dim)
                            drv_add_row(f"{label}:", value, color)
                        drv_status.configure(text="✔ Hardware info loaded.")
                    win.after(0, _ui)

                def _do_advanced():
                    skip = ["PCI bridge", "ISA bridge", "Host bridge", "System peripheral",
                            "Signal processing", "Communication controller", "I2C", "UART"]
                    try:
                        lines = sub.run(["lspci"], capture_output=True, text=True).stdout.splitlines()
                        def _ui():
                            for w in drv_list.winfo_children(): w.destroy()
                            for line in lines:
                                if not line.strip() or any(s.lower() in line.lower() for s in skip): continue
                                parts = line.split(" ", 1)
                                desc = parts[1].strip() if len(parts) > 1 else line
                                if ":" in desc:
                                    dtype, dname = desc.split(":", 1)
                                    drv_add_row(dtype.strip(), dname.strip())
                                else:
                                    drv_add_row(parts[0] if parts else "?", desc)
                            drv_status.configure(text="✔ Advanced devices loaded.")
                        win.after(0, _ui)
                    except Exception as e:
                        win.after(0, lambda: drv_status.configure(text=f"Error: {e}"))

                def load_basic():
                    current_view[0] = "basic"
                    for w in drv_list.winfo_children(): w.destroy()
                    drv_status.configure(text="⏳ Please be patient, loading hardware info...")
                    trd.Thread(target=_do_basic, daemon=True).start()

                def load_advanced():
                    current_view[0] = "advanced"
                    for w in drv_list.winfo_children(): w.destroy()
                    drv_status.configure(text="⏳ Please be patient, loading advanced info...")
                    trd.Thread(target=_do_advanced, daemon=True).start()

                def load_hw_info():
                    if current_view[0] == "advanced":
                        load_advanced()
                    else:
                        load_basic()

                ctk.CTkButton(drv_btn_row, text="Refresh", width=90, height=34,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=load_hw_info).pack(side="left", padx=(0,8))
                ctk.CTkButton(drv_btn_row, text="Fix / Auto-install", width=140, height=34,
                    fg_color=clr_green, hover_color=clr_green_h,
                    command=lambda: _fix_drivers()).pack(side="left", padx=(0,8))

                def _fix_drivers():
                    fix_win = ctk.CTkToplevel(sys_win)
                    fix_win.title("Fix / Auto-install Drivers")
                    fix_win.geometry("500x450")
                    fix_win.resizable(False, False)
                    fix_win.after(100, fix_win.grab_set)

                    ctk.CTkLabel(fix_win, text="Fix / Auto-install Drivers",
                        font=("Share Tech Mono", 16, "bold"), text_color=acc_color).pack(anchor="w", padx=15, pady=(12,0))
                    ctk.CTkLabel(fix_win, text="Running: pkexec ubuntu-drivers autoinstall",
                        font=("Share Tech Mono", 10, "italic"), text_color=clr_dim).pack(anchor="w", padx=15, pady=(0,6))

                    out_box = ctk.CTkTextbox(fix_win, font=("Share Tech Mono", 11), height=200)
                    out_box.pack(fill="x", padx=15, pady=(0,8))
                    out_box.insert("end", "⏳ Please wait, installing drivers...\n")

                    status_lbl = ctk.CTkLabel(fix_win, text="", font=("Share Tech Mono", 11),
                        text_color=clr_dim, anchor="w")
                    status_lbl.pack(anchor="w", padx=15)

                    # Ask row — hidden until needed
                    ask_row = ctk.CTkFrame(fix_win, fg_color="transparent")
                    # not packed yet

                    close_btn = ctk.CTkButton(fix_win, text="Please wait...", width=120, height=34,
                        fg_color=clr_grey, hover_color=clr_grey_h, state="disabled",
                        command=fix_win.destroy)
                    close_btn.pack(pady=(8,12))

                    def _r():
                        try:
                            result = sub.run(
                                ["pkexec", "ubuntu-drivers", "autoinstall"],
                                capture_output=True, text=True
                            )
                            out = (result.stdout + result.stderr).strip()
                            def _ui():
                                out_box.insert("end", out if out else "(no output)")
                                if result.returncode == 0:
                                    status_lbl.configure(text="✔ Done! Checking restart setting...", text_color=clr_green)
                                    after = stg.get("System", "after_driver_fix", fallback="Ask")
                                    if after == "Restart":
                                        status_lbl.configure(text="✔ Done! Restarting...")
                                        close_btn.configure(text="Close", state="normal")
                                        win.after(2000, lambda: sub.run(["pkexec", "reboot"]))
                                    elif after == "Do Nothing":
                                        status_lbl.configure(text="✔ Done! Restart manually when ready.", text_color=clr_green)
                                        close_btn.configure(text="Close", state="normal")
                                    else:  # Ask
                                        status_lbl.configure(text="✔ Done! Restart required.", text_color=clr_green)
                                        ask_row.pack(pady=(4,0))
                                        ctk.CTkLabel(ask_row, text="Restart now?",
                                            font=("Share Tech Mono", 12), text_color="white").pack(side="left", padx=(0,12))
                                        ctk.CTkButton(ask_row, text="Yes, Restart", width=110, height=32,
                                            fg_color=clr_green, hover_color=clr_green_h,
                                            command=lambda: sub.run(["pkexec", "reboot"])).pack(side="left", padx=(0,8))
                                        ctk.CTkButton(ask_row, text="Later", width=70, height=32,
                                            fg_color=clr_grey, hover_color=clr_grey_h,
                                            command=fix_win.destroy).pack(side="left")
                                        close_btn.configure(text="Close", state="normal")
                                else:
                                    status_lbl.configure(text=f"⚠ Error (code {result.returncode})", text_color=clr_red)
                                    close_btn.configure(text="Close", state="normal")
                            win.after(0, _ui)
                        except Exception as e:
                            win.after(0, lambda: [
                                out_box.insert("end", f"Error: {e}"),
                                status_lbl.configure(text="⚠ Failed to run.", text_color=clr_red),
                                close_btn.configure(text="Close", state="normal")
                            ])
                    trd.Thread(target=_r, daemon=True).start()
                ctk.CTkButton(drv_btn_row, text="Basic", width=80, height=34,
                    fg_color=clr_grey, hover_color=clr_grey_h,
                    command=load_basic).pack(side="left", padx=(0,8))
                ctk.CTkButton(drv_btn_row, text="Advanced", width=90, height=34,
                    fg_color=clr_grey, hover_color=clr_grey_h,
                    command=load_advanced).pack(side="left")

                load_basic()
                ctk.CTkLabel(sys_apps, text="Apps", font=("Share Tech Mono", 22, "bold", "italic"),
                    text_color=acc_color).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(sys_apps, text="Terminate, view info & manual for running apps",
                    font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15, pady=(0,4))

                # ── Search row ──
                search_row = ctk.CTkFrame(sys_apps, fg_color="transparent")
                search_row.pack(fill="x", padx=15, pady=(0,4))
                ctk.CTkLabel(search_row, text="🔍", font=("Share Tech Mono", 13)).pack(side="left", padx=(0,6))
                app_search = ctk.CTkEntry(search_row, font=("Share Tech Mono", 11),
                    placeholder_text="Filter by name or PID...")
                app_search.pack(side="left", fill="x", expand=True, padx=(0,8))
                ctk.CTkButton(search_row, text="Refresh", width=75, height=30,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=lambda: load_app_list()).pack(side="left")

                # ── App list ──
                app_list_frame = ctk.CTkScrollableFrame(sys_apps, fg_color="transparent", height=200,
                    scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h,
                    border_width=2, border_color=acc_color)
                app_list_frame.pack(fill="x", padx=15, pady=(0,4))

                # Header
                hdr = ctk.CTkFrame(app_list_frame, fg_color=acc_active)
                hdr.pack(fill="x", pady=(0,2))
                for txt, w in [("PID", 60), ("Name", 160), ("CPU%", 55), ("MEM%", 55), ("Command", 170)]:
                    ctk.CTkLabel(hdr, text=txt, font=("Share Tech Mono", 10, "bold"),
                        text_color="white", width=w, anchor="w").pack(side="left", padx=4, pady=3)

                app_status = ctk.CTkLabel(sys_apps, text="", font=("Share Tech Mono", 10, "italic"),
                    text_color=clr_dim, anchor="w")
                app_status.pack(anchor="w", padx=15)

                selected_app = [None]  # [pid]
                all_procs = []

                def load_app_list():
                    app_status.configure(text="⏳ Loading processes...")
                    for w in app_list_frame.winfo_children():
                        if w != hdr: w.destroy()
                    def _r():
                        try:
                            result = sub.run(["ps", "aux", "--sort=-%cpu"],
                                capture_output=True, text=True)
                            lines = result.stdout.splitlines()[1:]  # skip header
                            procs = []
                            for line in lines:
                                parts = line.split(None, 10)
                                if len(parts) < 11: continue
                                pid, cpu, mem, cmd = parts[1], parts[2], parts[3], parts[10]
                                name = cmd.split("/")[-1].split()[0][:20]
                                procs.append((pid, name, cpu, mem, cmd[:40]))
                            all_procs.clear()
                            all_procs.extend(procs)
                            win.after(0, lambda: render_list(app_search.get().strip()))
                        except Exception as e:
                            win.after(0, lambda: app_status.configure(text=f"Error: {e}"))
                    trd.Thread(target=_r, daemon=True).start()

                def render_list(query=""):
                    for w in list(app_list_frame.winfo_children()):
                        if w == hdr: continue
                        w.destroy()
                    filtered = [p for p in all_procs
                        if not query or query.lower() in p[1].lower() or query in p[0]]
                    for pid, name, cpu, mem, cmd in filtered[:80]:
                        row = ctk.CTkFrame(app_list_frame, fg_color="transparent", cursor="hand2")
                        row.pack(fill="x", pady=1)
                        ctk.CTkLabel(row, text=pid,  font=("Share Tech Mono", 10), text_color=acc_color,  width=60,  anchor="w").pack(side="left", padx=4)
                        ctk.CTkLabel(row, text=name, font=("Share Tech Mono", 10),      text_color="white",    width=160, anchor="w").pack(side="left", padx=4)
                        ctk.CTkLabel(row, text=cpu,  font=("Share Tech Mono", 10), text_color=clr_dim,    width=55,  anchor="w").pack(side="left", padx=4)
                        ctk.CTkLabel(row, text=mem,  font=("Share Tech Mono", 10), text_color=clr_dim,    width=55,  anchor="w").pack(side="left", padx=4)
                        ctk.CTkLabel(row, text=cmd,  font=("Share Tech Mono", 9),  text_color=clr_dim,    width=170, anchor="w").pack(side="left", padx=4)

                        def on_select(p=pid, n=name, r=row):
                            selected_app[0] = p
                            app_entry.delete(0, "end")
                            app_entry.insert(0, p)
                            app_status.configure(text=f"Selected: {n} (PID {p})")
                            for child in app_list_frame.winfo_children():
                                if child != hdr:
                                    child.configure(fg_color="transparent")
                            r.configure(fg_color=acc_subtle)

                        row.bind("<Button-1>", lambda e, fn=on_select: fn())
                        for child in row.winfo_children():
                            child.bind("<Button-1>", lambda e, fn=on_select: fn())

                    app_status.configure(text=f"✔ {len(filtered)} process(es) shown.")

                app_search.bind("<KeyRelease>", lambda e: render_list(app_search.get().strip()))

                # ── Name/PID entry ──
                app_row = ctk.CTkFrame(sys_apps, fg_color="transparent")
                app_row.pack(fill="x", padx=15, pady=(4,4))
                ctk.CTkLabel(app_row, text="Name / PID:", font=("Share Tech Mono", 12),
                    text_color=acc_color).pack(side="left", padx=(0,8))
                app_entry = ctk.CTkEntry(app_row, font=("Share Tech Mono", 11),
                    placeholder_text="Click a row above or type manually")
                app_entry.pack(side="left", fill="x", expand=True)

                app_output = ctk.CTkTextbox(sys_apps, height=80, font=("Share Tech Mono", 11))
                app_output.pack(fill="x", padx=15, pady=(0,4))
                app_btn_row = ctk.CTkFrame(sys_apps, fg_color="transparent")
                app_btn_row.pack(fill="x", padx=15)

                def app_run(cmd_list, label):
                    name = app_entry.get().strip()
                    if not name:
                        app_output.delete("1.0", "end")
                        app_output.insert("end", "⚠ Select an app from the list or type a name/PID.")
                        return
                    app_output.delete("1.0", "end")
                    app_output.insert("end", f"Running: {label} '{name}'...\n\n")
                    full_cmd = [c.replace("__NAME__", name) for c in cmd_list]
                    def _r():
                        try:
                            result = sub.run(full_cmd, capture_output=True, text=True)
                            out = result.stdout + result.stderr
                            win.after(0, lambda: app_output.insert("end", out or "(no output)"))
                        except Exception as e:
                            win.after(0, lambda: app_output.insert("end", f"Error: {e}"))
                    trd.Thread(target=_r, daemon=True).start()

                ctk.CTkButton(app_btn_row, text="Terminate", width=100, height=34,
                    fg_color=clr_red, hover_color=clr_red_h,
                    command=lambda: app_run(["pkexec", "kill", "-9", "__NAME__"], "Terminate")).pack(side="left", padx=(0,8))
                ctk.CTkButton(app_btn_row, text="App Info", width=90, height=34,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=lambda: app_run(["ps", "-p", "__NAME__", "-o", "pid,ppid,cmd,%mem,%cpu"], "App Info")).pack(side="left", padx=(0,8))
                ctk.CTkButton(app_btn_row, text="Manual", width=80, height=34,
                    fg_color=clr_grey, hover_color=clr_grey_h,
                    command=lambda: app_run(["man", "__NAME__"], "Manual")).pack(side="left")

                load_app_list()

                # ── OS ──
                ctk.CTkLabel(sys_os, text="OS", font=("Share Tech Mono", 22, "bold", "italic"),
                    text_color=acc_color).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(sys_os, text="Kernel, system info & users",
                    font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15, pady=(0,6))
                os_output = ctk.CTkTextbox(sys_os, height=230, font=("Share Tech Mono", 11))
                os_output.pack(fill="x", padx=15, pady=(0,6))
                os_btn_row = ctk.CTkFrame(sys_os, fg_color="transparent")
                os_btn_row.pack(fill="x", padx=15, pady=(0,4))

                def os_run(cmd_list, label):
                    os_output.delete("1.0", "end")
                    os_output.insert("end", f"── {label} ──\n\n")
                    def _r():
                        try:
                            result = sub.run(cmd_list, capture_output=True, text=True)
                            out = result.stdout + result.stderr
                            win.after(0, lambda: os_output.insert("end", out or "(no output)"))
                        except Exception as e:
                            win.after(0, lambda: os_output.insert("end", f"Error: {e}"))
                    trd.Thread(target=_r, daemon=True).start()

                def check_kernel_stable():
                    os_output.delete("1.0", "end")
                    os_output.insert("end", "── Kernel Stability Check ──\n\n")
                    def _r():
                        try:
                            kernel = sub.run(["uname", "-r"], capture_output=True, text=True).stdout.strip()
                            if "generic" in kernel or "lts" in kernel.lower():
                                status = "✔ Stable (Ubuntu generic/LTS kernel)"
                            elif "rc" in kernel or "unstable" in kernel:
                                status = "⚠ Unstable (Release Candidate detected)"
                            else:
                                status = "? Unknown — custom or third-party kernel"
                            win.after(0, lambda: os_output.insert("end", f"Kernel: {kernel}\nStatus: {status}\n"))
                        except Exception as e:
                            win.after(0, lambda: os_output.insert("end", f"Error: {e}"))
                    trd.Thread(target=_r, daemon=True).start()

                def show_users():
                    os_output.delete("1.0", "end")
                    os_output.insert("end", "── Users ──\n\n")
                    def _r():
                        try:
                            import pwd as _pwd
                            result = sub.run(["getent", "group", "sudo"], capture_output=True, text=True)
                            admins = result.stdout.strip().split(":")[-1].split(",") if result.returncode == 0 else []
                            lines = []
                            for p in _pwd.getpwall():
                                if p.pw_uid >= 1000 and p.pw_shell not in ("/sbin/nologin", "/bin/false", "/usr/sbin/nologin"):
                                    utype = "Admin" if p.pw_name in admins else "Standard"
                                    lines.append(f"{p.pw_name:<20} {utype}")
                            out = "Username             Type\n" + "─"*30 + "\n" + "\n".join(lines) if lines else "(no users found)"
                            win.after(0, lambda: os_output.insert("end", out))
                        except Exception as e:
                            win.after(0, lambda: os_output.insert("end", f"Error: {e}"))
                    trd.Thread(target=_r, daemon=True).start()

                ctk.CTkButton(os_btn_row, text="Kernel Version", width=115, height=34,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=lambda: os_run(["uname", "-r"], "Kernel Version")).pack(side="left", padx=(0,8))
                ctk.CTkButton(os_btn_row, text="Kernel Stable?", width=115, height=34,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=check_kernel_stable).pack(side="left", padx=(0,8))
                ctk.CTkButton(os_btn_row, text="OS Info", width=80, height=34,
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=lambda: os_run(["neofetch", "--stdout"], "OS Info")).pack(side="left", padx=(0,8))
                ctk.CTkButton(os_btn_row, text="Users", width=70, height=34,
                    fg_color=clr_grey, hover_color=clr_grey_h,
                    command=show_users).pack(side="left", padx=(0,8))

                show_sys_main()

            # ── GNU/GRUB stub ──
            def toGNUGRUB():
                g = ctk.CTkToplevel(win)
                g.title("GNU/GRUB")
                g.geometry(f"{geometry[0]}x{geometry[1]}")
                g.resizable(False, False)
                f = ctk.CTkFrame(g, fg_color="transparent")
                f.pack(fill="both", expand=True, padx=20, pady=20)
                ctk.CTkLabel(f, text="GNU/GRUB", font=("Share Tech Mono", 24, "bold", "italic"), text_color=acc_color).pack(anchor="w")
                ctk.CTkLabel(f, text="Bootloader tools — Coming Soon!",
                    font=("Share Tech Mono", 12), text_color=clr_dim).pack(anchor="w", pady=(4, 0))
                bottom = ctk.CTkFrame(g, corner_radius=0, height=60, fg_color=acc_color)
                bottom.pack(side="bottom", fill="x")
                bottom.pack_propagate(False)
                ctk.CTkButton(bottom, text="Back", width=90, height=36, corner_radius=50,
                    fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border,
                    command=g.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom, text="Home", width=90, height=36, corner_radius=50,
                    fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border,
                    command=g.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(bottom, text="Help", width=90, height=36, corner_radius=50,
                    fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border,
                    text_color="white", command=lambda: show_help(win, "grub")).pack(side="left", padx=(60, 0), pady=12)

            # ── Cheatsheet ──
            def toCheatsheet():
                cs_win = ctk.CTkToplevel(win)
                cs_win.title("Cheatsheet")
                cs_win.geometry(f"{geometry[0]}x{geometry[1]}")
                cs_win.resizable(False, False)
                cs_win.after(100, cs_win.grab_set)

                ctk.CTkLabel(cs_win, text="Cheatsheet", font=("Share Tech Mono", 24, "bold", "italic"),
                    text_color=acc_color).pack(anchor="w", padx=15, pady=(10, 0))
                ctk.CTkLabel(cs_win, text="Linux Terminal Commands",
                    font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15)

                # ── Sub-page frames ──
                cs_main   = ctk.CTkFrame(cs_win, fg_color="transparent")
                cs_simple = ctk.CTkFrame(cs_win, fg_color="transparent")
                cs_adv    = ctk.CTkFrame(cs_win, fg_color="transparent")

                # ── Shared bottom bar on cs_win ──
                cs_bar = ctk.CTkFrame(cs_win, corner_radius=0, height=60, fg_color=acc_color)
                cs_bar.pack(side="bottom", fill="x")
                cs_bar.pack_propagate(False)
                cs_back_btn = ctk.CTkButton(cs_bar, text="Back", width=90, height=36, corner_radius=50,
                    fg_color=acc_active, hover_color=acc_hover, border_width=3, border_color=acc_border,
                    command=cs_win.destroy)
                cs_back_btn.pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(cs_bar, text="Home", width=90, height=36, corner_radius=50,
                    fg_color=clr_orange, hover_color=clr_orange_h, border_width=3, border_color=acc_border,
                    command=cs_win.destroy).pack(side="left", padx=(60, 0), pady=12)
                ctk.CTkButton(cs_bar, text="Help", width=90, height=36, corner_radius=50,
                    fg_color=clr_green, hover_color=clr_green_h, border_width=3, border_color=acc_border,
                    text_color="white", command=lambda: show_help(win, "cheatsheet")).pack(side="left", padx=(60, 0), pady=12)
                if cpu_mem_enabled:
                    try: _make_cpu_label(cs_bar)
                    except NameError: pass

                def show_cs_main():
                    cs_simple.pack_forget(); cs_adv.pack_forget()
                    cs_main.pack(fill="both", expand=True)
                    cs_back_btn.configure(command=cs_win.destroy)

                def show_simple():
                    cs_main.pack_forget(); cs_adv.pack_forget()
                    cs_simple.pack(fill="both", expand=True)
                    cs_back_btn.configure(command=show_cs_main)

                def show_adv():
                    cs_main.pack_forget(); cs_simple.pack_forget()
                    cs_adv.pack(fill="both", expand=True)
                    cs_back_btn.configure(command=show_cs_main)

                # ── Main selector (like toPKG) ──
                btn_frame = ctk.CTkFrame(cs_main, width=575, height=120,
                    border_color=acc_color, border_width=2, fg_color="transparent")
                btn_frame.place(x=5, y=20)
                btn_frame.pack_propagate(False)
                ctk.CTkButton(btn_frame, width=560, height=40, text="Simple",
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=show_simple).pack(pady=(5, 0), anchor="center")
                ctk.CTkButton(btn_frame, width=560, height=40, text="Advanced",
                    fg_color=acc_color, hover_color=acc_hover, text_color=acc_fg,
                    command=show_adv).pack(pady=(20, 0), anchor="center")

                # ── Command table builder ──
                def build_table(parent, commands):
                    ctk.CTkLabel(parent, text="💡 Click a row to copy the example!",
                        font=("Share Tech Mono", 11, "italic"), text_color=clr_dim).pack(anchor="w", padx=15, pady=(8, 4))

                    table = ctk.CTkScrollableFrame(parent, fg_color="transparent",
                        scrollbar_button_color=clr_scroll, scrollbar_button_hover_color=clr_scroll_h,
                        border_width=2, border_color=acc_color, height=300)
                    table.pack(fill="x", padx=15, pady=(0, 6))

                    # Header
                    hdr = ctk.CTkFrame(table, fg_color=acc_active)
                    hdr.pack(fill="x", pady=(0, 2))
                    for txt, w in [("Command", 100), ("Purpose", 200), ("Example", 200)]:
                        ctk.CTkLabel(hdr, text=txt, font=("Share Tech Mono", 11, "bold"),
                            text_color="white", width=w, anchor="w").pack(side="left", padx=6, pady=4)

                    for cmd, purpose, example in commands:
                        row = ctk.CTkFrame(table, fg_color="transparent", cursor="hand2")
                        row.pack(fill="x", pady=1)
                        lbl_cmd     = ctk.CTkLabel(row, text=cmd, font=("Share Tech Mono", 11, "bold"),
                            text_color=acc_color, width=100, anchor="w")
                        lbl_cmd.pack(side="left", padx=6)
                        lbl_purpose = ctk.CTkLabel(row, text=purpose, font=("Share Tech Mono", 10),
                            text_color="white", width=200, anchor="w", wraplength=195)
                        lbl_purpose.pack(side="left", padx=6)
                        lbl_example = ctk.CTkLabel(row, text=example, font=("Share Tech Mono", 10),
                            text_color=clr_dim, width=200, anchor="w", wraplength=195)
                        lbl_example.pack(side="left", padx=6)

                        def on_copy(e, ex=example):
                            cs_win.clipboard_clear()
                            cs_win.clipboard_append(ex)
                            copied_lbl.configure(text=f"✔ Copied: {ex}")
                            cs_win.after(2000, lambda: copied_lbl.configure(text=""))

                        def on_enter(e, r=row): r.configure(fg_color=acc_subtle)
                        def on_leave(e, r=row): r.configure(fg_color="transparent")
                        for w in [row, lbl_cmd, lbl_purpose, lbl_example]:
                            w.bind("<Button-1>", on_copy)
                            w.bind("<Enter>", on_enter)
                            w.bind("<Leave>", on_leave)

                    return table

                # ── Simple commands ──
                simple_cmds = [
                    ("ls",      "List files in directory",          "ls -la <directory>"),
                    ("cd",      "Change directory",                 "cd <path>"),
                    ("pwd",     "Print working directory",          "pwd"),
                    ("mkdir",   "Create a directory",               "mkdir <folder name>"),
                    ("rm",      "Remove file or folder",            "rm -rf <file/folder>"),
                    ("cp",      "Copy file or folder",              "cp <source> <destination>"),
                    ("mv",      "Move or rename file",              "mv <source> <destination>"),
                    ("cat",     "Print file contents",              "cat <file>"),
                    ("nano",    "Edit file in terminal",            "nano <file>"),
                    ("apt",     "Package manager",                  "sudo apt install <package>"),
                    ("flatpak", "Flatpak package manager",          "flatpak install flathub <app.id>"),
                    ("clear",   "Clear terminal screen",            "clear"),
                    ("echo",    "Print text to terminal",           "echo <text>"),
                    ("man",     "Show manual for a command",        "man <command>"),
                    ("history", "Show command history",             "history"),
                    ("sudo",    "Run as superuser",                 "sudo <command>"),
                    ("reboot",  "Restart the system",               "sudo reboot"),
                    ("shutdown","Shut down the system",             "sudo shutdown -h <now/+minutes>"),
                ]

                # ── Advanced commands ──
                adv_cmds = [
                    ("chmod",     "Change file permissions",        "chmod <permissions> <file>"),
                    ("chown",     "Change file owner",              "chown <user>:<group> <file>"),
                    ("grep",      "Search text in files",           "grep -r '<text>' <directory>"),
                    ("find",      "Find files by name/type",        "find <directory> -name '<pattern>'"),
                    ("ps",        "List running processes",         "ps aux | grep <process name>"),
                    ("kill",      "Kill a process by PID",          "kill -9 <PID>"),
                    ("top",       "Live process monitor",           "top"),
                    ("df",        "Disk usage",                     "df -h"),
                    ("du",        "Directory size",                 "du -sh <directory>"),
                    ("tar",       "Archive/extract files",          "tar -xzf <file.tar.gz> -C <destination>"),
                    ("ssh",       "Connect to remote server",       "ssh <user>@<host>"),
                    ("scp",       "Copy file over SSH",             "scp <file> <user>@<host>:<destination>"),
                    ("wget",      "Download file from URL",         "wget <url>"),
                    ("curl",      "Transfer data from URL",         "curl -O <url>"),
                    ("systemctl", "Manage system services",         "sudo systemctl <start/stop/restart> <service>"),
                    ("journalctl","View system logs",               "journalctl -xe"),
                    ("sed",       "Stream text editor",             "sed -i 's/<old>/<new>/g' <file>"),
                    ("awk",       "Text processing",                "awk '{print $<column>}' <file>"),
                    ("crontab",   "Schedule tasks",                 "crontab -e"),
                    ("netstat",   "Network connections",            "netstat -tulpn"),
                    ("ufw",       "Manage firewall",                "sudo ufw <enable/disable/allow/deny> <port>"),
                    ("lsblk",     "List block devices",             "lsblk"),
                    ("mount",     "Mount a filesystem",             "sudo mount <device> <mountpoint>"),
                ]

                build_table(cs_simple, simple_cmds)
                build_table(cs_adv, adv_cmds)

                # ── Copied feedback label ──
                copied_lbl = ctk.CTkLabel(cs_win, text="", font=("Share Tech Mono", 10),
                    text_color=clr_green)
                copied_lbl.pack(anchor="w", padx=15)

                show_cs_main()

            win.mainloop()

TUI.Program.app()