################################
#TUI_INSTALLATION_WIZARD
#PLEASE DONT TOUCH OR EDIT FILE
################################
import os
import sys
from externals import updater as upd
#upd.start()
from pathlib import Path
import getpass as gp
from subprocess import run as cmd
import requests as rqs
import customtkinter as ctk
import threading as trd

username = gp.getuser()
file_path = Path(__file__).resolve()


# Automatically discover target installation file infrastructure
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Safely point to the asset relative to the running script location
IMAGE_PATH = os.path.join(BASE_DIR, "images", "img1.png")

# Source code URL to fetch main.py from (Updated with your custom production endpoint)
SOURCE_CODE_URL = "https://packages-gitcat.netlify.app/packages/tui/1/source-code-1_0_0.tar.gz"

class TUI_INSTALLER():   
    class Program():
        def App():
            import tkinter as tk
            window_wiz = ctk.CTk(className="TUI")
            window_wiz.title("Install")
            window_wiz.geometry("500x500")

            ctk.set_appearance_mode("dark")

            # ── Icon ──
            def _set_icon():
                try:
                    window_wiz._icon = tk.PhotoImage(
                        file=os.path.join(BASE_DIR, "resources", "icons", "win_icon.png"))
                    window_wiz.iconphoto(False, window_wiz._icon)
                except Exception as e:
                    print(f"Icon error: {e}")
            window_wiz.after(100, _set_icon)

            frame_main = ctk.CTkFrame(window_wiz)
            frame_main.pack(expand=True, fill="both")

            def pages(page_no=0):
                for widget in frame_main.winfo_children():
                    widget.destroy()
                
                if page_no == 1:
                    ctk.CTkLabel(frame_main, text="T.U.I | Terminal.User.Interface\nInstaller",
                        justify="center", font=("Share Tech Mono", 22, "italic"),
                        text_color="#3e3c88", wraplength=460).pack(pady=(10, 0))
                    ctk.CTkLabel(frame_main, text="Welcome to the T.U.I installer wizard\nClick <Start> to start!",
                        justify="center", font=("Share Tech Mono", 13, "italic"),
                        text_color="#4f6fb4", wraplength=460).pack(pady=(4, 8))
                    
                    ctk.CTkButton(frame_main, text="Start", font=("Share Tech Mono", 13), fg_color="#f7dc42", hover_color="#ffec7d", text_color="#000000", command=lambda :pages(2)).place(relx=0.97, rely=0.97, anchor="se")
                    ctk.CTkButton(frame_main, text="Quit", font=("Share Tech Mono", 13), fg_color="#ff0000", hover_color="#ff3f3f", text_color="#FFFFFF", command=lambda :exit()).place(relx=0.03, rely=0.97, anchor="sw")

                elif page_no == 2:
                    ctk.CTkLabel(frame_main, text="There isn't much in this installation\nYou can start the installation now!\n!!!NOTE!!!\nyou will need to type your password\nalot...",
                        justify="center", font=("Share Tech Mono", 15, "italic"),
                        text_color="#4f6fb4", wraplength=460).pack(pady=(20, 8))

                    ctk.CTkButton(frame_main, text="Install", font=("Share Tech Mono", 13), fg_color="#33ff00", hover_color="#74ff62", text_color="#FFFFFF", command=lambda :pages(3)).place(relx=0.97, rely=0.97, anchor="se")
                    ctk.CTkButton(frame_main, text="Back", font=("Share Tech Mono", 13), fg_color="#0026ff", hover_color="#516bff", text_color="#FFFFFF", command=lambda :pages(1)).place(relx=0.03, rely=0.97, anchor="sw")
                
                elif page_no == 3:
                    ctk.CTkLabel(frame_main, text="Installing...", text_color="#3e3c88", font=("Share Tech Mono", 40, "bold")).pack(pady=10)
                    
                    progress_label = ctk.CTkLabel(frame_main, text="[6/0] Starting...", font=("Share Tech Mono", 13), text_color="#3e3c88")
                    progress_label.pack(anchor="w", padx=20, pady=(10, 2))
                    
                    progress_install = ctk.CTkProgressBar(frame_main, corner_radius=50, height=20, progress_color="#6b67da")
                    progress_install.pack(fill="x", padx=20, pady=10)
                    progress_install.set(0.0)
                    
                    quit_btn = ctk.CTkButton(frame_main, text="Quit", font=("Share Tech Mono", 13), fg_color="#ff0000", hover_color="#ff3f3f", text_color="#FFFFFF", command=lambda :exit())
                    quit_btn.place(relx=0.03, rely=0.97, anchor="sw")

                    # Helper functions to update GUI elements from the background thread safely
                    def update_gui(text, progress_val):
                        window_wiz.after(0, lambda: progress_label.configure(text=text))
                        window_wiz.after(0, lambda: progress_install.set(progress_val))

                    # The sequence runner running inside the worker thread
                    def installation_sequence():
                        try:
                            # Step 1: Create Directories
                            update_gui("[6/1] Creating Folders...", 0.15)
                            dirs_to_create = ['/usr/share/tui/']
                            cmd(['pkexec', 'mkdir', '-p'] + dirs_to_create, check=True)
                            
                            # Step 2: Fetch Resources
                            update_gui("[6/2] Fetching Resources...", 0.3)
                            resources_path = os.path.join(BASE_DIR, "resources")
                            if os.path.exists(resources_path):
                                cmd(['pkexec', 'cp', '-r', resources_path, '/usr/share/tui/'], check=True)
                            
                            # Step 3: Get Source Code and Write with pkexec + tee
                            update_gui("[6/3] Getting Program...", 0.5)
                            response = rqs.get(SOURCE_CODE_URL)
                            response.raise_for_status()
                            source_code = response.text
                            
                            # Pipe code data to tee command executed under root permissions
                            cmd(
                                ['pkexec', 'tee', '/usr/share/tui/main.py'],
                                input=source_code,
                                text=True,
                                capture_output=True,
                                check=True
                            )
                            
                            # Step 4: Create .Desktop launcher for application
                            update_gui("[6/4] Creating launcher...", 0.7)
                            desktop_ini = "[Desktop Entry]\nVersion=1.0\nType=Application\nName=T.U.I\nComment=Be free, The easy way...\nExec=python3 /usr/share/tui/main.py\nIcon=/usr/share/tui/resources/icons/win_icon.png\nTerminal=false\nCategories=Utility;Development;\nStartupNotify=true"

                            cmd(
                                ['pkexec', 'tee', '/usr/share/applications/tui-linux.desktop'],
                                input=desktop_ini,
                                text=True,
                                capture_output=True,
                                check=True
                            )
                            
                            # Step 5: Generate and Drop uninstaller.sh file with tee
                            update_gui("[6/5] Injecting Uninstaller...", 0.85)
                            uninstaller_payload = (
                                "#!/bin/bash\n\n"
                                "if [ \"$EUID\" -ne 0 ]; then\n"
                                "  pkexec bash \"$0\"\n"
                                "  exit\n"
                                "fi\n\n"
                                "echo 'Removing T.U.I system assets...'\n"
                                "rm -f /usr/share/applications/tui-linux.desktop\n"
                                "rm -f /usr/share/applications/T.U.I-Uninstaller.desktop\n"
                                "rm -rf /usr/share/tui\n"
                                "rm -rf ~.TUI\n"
                                "if command -v update-desktop-database &> /dev/null; then\n"
                                "  update-desktop-database /usr/share/applications/\n"
                                "fi\n"
                                "echo 'Uninstall complete!'\n"
                            )
                            
                            cmd(
                                ['pkexec', 'tee', '/usr/share/tui/uninstall.sh'],
                                input=uninstaller_payload,
                                text=True,
                                capture_output=True,
                                check=True
                            )
                            # Make the generated script dynamically executable
                            cmd(['pkexec', 'chmod', '+x', '/usr/share/tui/uninstall.sh'], check=True)

                            # Step 6: Create .Desktop Launcher for the system uninstaller
                            update_gui("[6/6] Registering System Controls...", 0.95)
                            uninstaller_desktop = (
                                "[Desktop Entry]\n"
                                "Version=1.0\n"
                                "Type=Application\n"
                                "Name=T.U.I-Uninstaller\n"
                                "Comment=Completely remove T.U.I from your system\n"
                                "Exec=gnome-terminal -- bash -c \"/usr/share/tui/uninstall.sh; read -p 'Press enter to exit...'\"\n"
                                "Icon=/usr/share/tui/resources/icons/win_icon.png\n"
                                "Terminal=false\n"
                                "Categories=Utility;\n"
                                "StartupNotify=true"
                            )
                            
                            cmd(
                                ['pkexec', 'tee', '/usr/share/applications/T.U.I-Uninstaller.desktop'],
                                input=uninstaller_desktop,
                                text=True,
                                capture_output=True,
                                check=True
                            )
                            
                            # Refresh application launcher mapping caches
                            if os.path.exists("/usr/share/applications"):
                                cmd(['pkexec', 'update-desktop-database', '/usr/share/applications/'], errors='ignore')

                            # Finalizing installation successfully
                            update_gui("[6/6] Done!", 1.0)
                            window_wiz.after(0, lambda: quit_btn.configure(text="Finish", fg_color="#33ff00", hover_color="#74ff62"))
                        
                        except Exception as error_msg:
                            # Catch system / network errors and surface them cleanly on screen
                            update_gui(f"Error: {str(error_msg)[:35]}", 0.0)
                            print(f"Installation failed: {error_msg}")

                    # Spawn the process routine dynamically so the window mainloop never halts
                    worker_thread = trd.Thread(target=installation_sequence, daemon=True)
                    worker_thread.start()
                    
                else:
                    ctk.CTkLabel(frame_main, text="Oops!\n503 | !NOT FOUND!", font=("Share Tech Mono", 50, "bold"), text_color="#3e3c88").place(relx=0.5, rely=0.5, anchor="center")
            pages(1)
            
            window_wiz.mainloop()

# Instantiate the script entry point
if __name__ == "__main__":
    import distro
    
    # Cleanly check if the OS id is ubuntu, or inherits from it
    current_id = distro.id().lower()
    parent_families = distro.like().lower().split()
    
    if current_id == "ubuntu" or "ubuntu" in parent_families:
        # Launch app if it passes structural operating family platform check
        TUI_INSTALLER.Program.App()
    else:
        # Graphical error popup for non-Ubuntu users using standard tkinter
        import tkinter as tk
        from tkinter import messagebox
        
        root = tk.Tk()
        root.withdraw() # Hide the blank root element window
        
        messagebox.showerror(
            title="Incompatible OS", 
            message=f"Installation aborted!\n\nThis installer only supports Ubuntu-based systems.\nYour system: {distro.name()}"
        )
        root.destroy();