import os
import sys  
import site 
from subprocess import run

#!!!DONT CHANGE ANY LINE OF CODE!!!

modules = ['customtkinter', 'requests', 'distro']

def start():
    # 1. Install system dependencies globally using pkexec
    print("Installing system dependencies...")
    run(['pkexec', 'apt', 'install', '-y', 'python3-pip', 'python3-tk', 'flatpak'])
        
    # 2. Install Python modules globally using pkexec + pip
    for module in modules:
        print(f"Installing {module} globally...")
        # REMOVED '--user' and ADDED 'pkexec' to elevate privileges globally
        run(['pkexec', sys.executable, '-m', 'pip', 'install', module, '--break-system-packages'])

